import mysql.connector
from app import app

client = app.test_client()

def ligacao_teste():
    conn = mysql.connector.connect(
        host='localhost', user='root', password='A12345-a', database='explora_art'
    )
    conn.autocommit = True
    return conn

print("INICIANDO VALIDACAO DAS 3 NOVAS SOLICITACOES...")

# ==============================================================================
# TESTE 1: Notificacao de pedido de adesao a comunidade para o administrador
# ==============================================================================
conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
# Garantir comunidade privada com criador admin (user_id=1)
cur.execute("SELECT id FROM comunidades WHERE nome = 'Comunidade Notif Teste'")
com = cur.fetchone()
if not com:
    cur.execute("INSERT INTO comunidades (criador_id, nome, descricao, tipo) VALUES (1, 'Comunidade Notif Teste', 'Comunidade teste', 'privada')")
    com_id = cur.lastrowid
    cur.execute("INSERT INTO comunidade_membros (comunidade_id, user_id, papel, estado, data_adesao) VALUES (%s, 1, 'administrador', 'ativo', NOW())", (com_id,))
else:
    com_id = com['id']

# Limpar registos de adesao e notificacoes anteriores deste teste para o utilizador artista (ID=3)
cur.execute("DELETE FROM comunidade_membros WHERE comunidade_id = %s AND user_id = 3", (com_id,))
cur.execute("DELETE FROM notificacoes WHERE user_id = 1 AND mensagem LIKE '%Comunidade Notif Teste%'")
conn.close()

# Utilizador 'artista' (ID=3) faz login e pede para aderir
client.get('/logout')
res_log_3 = client.post('/login', data={'identificador': 'artista', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)
assert res_log_3.status_code == 200

res_aderir = client.post(f'/comunidade/{com_id}/aderir', follow_redirects=True)
assert res_aderir.status_code == 200

# Login como admin (ID=1) e verificar notificacao na pagina /notificacoes
client.get('/logout')
client.post('/login', data={'identificador': 'admin', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)

res_notif_page = client.get('/notificacoes')
assert res_notif_page.status_code == 200
html_notif = res_notif_page.data.decode('utf-8')
assert 'Comunidade Notif Teste' in html_notif
assert 'pediu para aderir' in html_notif
print("[OK] TESTE 1: Notificacao de pedido de adesao recebida e visivel na aba das notificacoes!")

# ==============================================================================
# TESTE 2: Contador de conversas por ler na aba das mensagens
# ==============================================================================
conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
# Limpar mensagens pendentes entre subscrito (2) e artista (3)
cur.execute("DELETE FROM mensagens_diretas WHERE (remetente_id = 2 AND destinatario_id = 3) OR (remetente_id = 3 AND destinatario_id = 2)")
conn.close()

# Subscrito (ID=2) envia mensagem ao artista (ID=3)
client.get('/logout')
client.post('/login', data={'identificador': 'subscrito', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)
res_msg_envio = client.post('/mensagens/3', data={'texto': 'Mensagem teste para contador'}, follow_redirects=True)
assert res_msg_envio.status_code == 200

# Login como artista (ID=3)
client.get('/logout')
client.post('/login', data={'identificador': 'artista', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)

# 1. Verificar que a API e o HTML do menu mostram 1 conversa por ler
res_api_unread = client.get('/api/mensagens/nao-lidas')
assert res_api_unread.status_code == 200
assert res_api_unread.get_json()['total_conversas'] >= 1

res_feed = client.get('/')
html_feed = res_feed.data.decode('utf-8')
assert 'contador-mensagens' in html_feed

# 2. Artista abre a conversa /mensagens/2 (sem responder!)
res_abrir_chat = client.get('/mensagens/2')
assert res_abrir_chat.status_code == 200

# 3. Verificar que o contador de conversas por ler desapareceu (passou a 0)
res_api_pos = client.get('/api/mensagens/nao-lidas')
assert res_api_pos.get_json()['total_conversas'] == 0

conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
cur.execute("SELECT data_leitura FROM mensagens_diretas WHERE remetente_id = 2 AND destinatario_id = 3 ORDER BY id DESC LIMIT 1")
msg_read = cur.fetchone()
assert msg_read is not None and msg_read['data_leitura'] is not None, "Mensagem nao foi marcada como lida ao abrir"
conn.close()
print("[OK] TESTE 2: Contador de conversas por ler exibido e limpo automaticamente ao ler a mensagem!")

# ==============================================================================
# TESTE 3: Subscricao para utilizadores registados (Req. 15, 16, 17, 24)
# ==============================================================================
conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
# Garantir que utilizador 'artista' (ID=3) comeca como 'registado'
cur.execute("UPDATE utilizadores SET papel = 'registado' WHERE id = 3")
cur.execute("DELETE FROM pagamentos WHERE user_id = 3")
cur.execute("DELETE FROM subscricoes WHERE user_id = 3")
conn.close()

# Login como 'artista'
client.get('/logout')
client.post('/login', data={'identificador': 'artista', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)

# 1. Verificar botao no menu e secção de Subscricao nas Definições
res_def = client.get('/definicoes')
assert res_def.status_code == 200
html_def = res_def.data.decode('utf-8')
assert 'Subscrição ExploraART' in html_def
assert 'Subscrever ExploraART' in html_def

# 2. Aceder a pagina de subscricao e escolher Multibanco
res_sub_page = client.get('/subscrever')
assert res_sub_page.status_code == 200
assert '4.99' in res_sub_page.data.decode('utf-8')

res_pagar = client.post('/subscrever', data={'metodo_pagamento': 'multibanco'}, follow_redirects=True)
assert res_pagar.status_code == 200
html_pagar = res_pagar.data.decode('utf-8')
assert 'Integração SIBS (Simulada)' in html_pagar
assert 'Entidade' in html_pagar
assert 'Referência' in html_pagar

# 3. Confirmar pagamento simulado
conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
cur.execute("SELECT id FROM subscricoes WHERE user_id = 3 AND estado = 'pendente' ORDER BY id DESC LIMIT 1")
sub_pend = cur.fetchone()
assert sub_pend is not None
sub_id = sub_pend['id']
conn.close()

res_confirm = client.post(f'/confirmar-pagamento-sibs/{sub_id}', follow_redirects=True)
assert res_confirm.status_code == 200

# 4. Verificar que passou a subscrito na base de dados
conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
cur.execute("SELECT papel FROM utilizadores WHERE id = 3")
assert cur.fetchone()['papel'] == 'subscrito', "Utilizador nao foi promovido a 'subscrito'"

# Verificar notificacao de ativacao
cur.execute("SELECT * FROM notificacoes WHERE user_id = 3 AND mensagem LIKE '%subscrição ExploraART foi ativada%' ORDER BY id DESC LIMIT 1")
assert cur.fetchone() is not None, "Utilizador nao recebeu notificacao de subscricao ativada"
conn.close()

# 5. Cancelar subscricao nas Definicoes
res_canc = client.post('/cancelar-subscricao', follow_redirects=True)
assert res_canc.status_code == 200

conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
cur.execute("SELECT renovacao_automatica, estado FROM subscricoes WHERE id = %s", (sub_id,))
sub_cancelada = cur.fetchone()
assert sub_cancelada['renovacao_automatica'] == 0
assert sub_cancelada['estado'] == 'cancelada'

# Repor papel 'registado' para o artista
cur.execute("UPDATE utilizadores SET papel = 'registado' WHERE id = 3")
conn.close()
print("[OK] TESTE 3: Fluxo completo de subscricao, pagamento simulado SIBS e cancelamento validado a 100%!")

print("\nTODOS OS REQUISITOS FORAM TESTADOS E VALIDADOS COM 100% DE SUCESSO!")
