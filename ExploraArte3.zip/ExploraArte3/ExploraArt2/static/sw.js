const CACHE_NAME = 'exploraart-v1';
const RECURSOS = ['/', '/static/css/style.css', '/static/js/main.js'];

self.addEventListener('install', (e) => {
    e.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(RECURSOS)));
});

self.addEventListener('fetch', (e) => {
    e.respondWith(
        caches.match(e.request).then((res) => res || fetch(e.request))
    );
});