if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/static/sw.js')
        .then(() => console.log('Service Worker Registado com Sucesso.'))
        .catch((err) => console.log('Erro ao registar Service Worker:', err));
}

function gostarPublicacao(pubId) {
    fetch(`/publicacao/${pubId}/gosto`, { method: 'POST' })
        .then(r => {
            if (r.status === 401) {
                window.location.href = '/login';
                return null;
            }
            return r.json();
        })
        .then(d => {
            if (!d) return;
            const counter = document.getElementById(`gostos-count-${pubId}`);
            if (counter) counter.innerText = d.total;
            const btn = document.getElementById(`like-btn-${pubId}`);
            if (btn) {
                btn.innerHTML = (d.gostou ? '❤️ Gostei' : '🤍 Gostar') + ` (<span id="gostos-count-${pubId}">${d.total}</span>)`;
            }
        });
}

function alternarFavorito(pubId) {
    fetch(`/publicacao/${pubId}/favorito`, { method: 'POST' })
        .then(r => {
            if (r.status === 401) {
                window.location.href = '/login';
                return null;
            }
            return r.json();
        })
        .then(d => {
            if (!d) return;
            const btn = document.getElementById(`fav-btn-${pubId}`);
            if (btn) {
                btn.innerText = d.guardado ? '⭐ Guardado' : '☆ Guardar nos Favoritos';
                btn.style.color = d.guardado ? '#d35400' : '#555';
                btn.style.background = d.guardado ? '#fdf2e9' : '#fff';
            }
        });
}
