import sys
import os
import pytest
from werkzeug.security import generate_password_hash, check_password_hash

# Assegurar que a pasta do projeto ExploraArt2 está no PYTHONPATH
diretorio_atual = os.path.abspath(os.path.dirname(__file__))
if os.path.exists(os.path.join(diretorio_atual, 'ExploraArt2')):
    pasta_app = os.path.join(diretorio_atual, 'ExploraArt2')
elif os.path.basename(diretorio_atual) == 'tests':
    pasta_app = os.path.dirname(diretorio_atual)
else:
    pasta_app = diretorio_atual

if pasta_app not in sys.path:
    sys.path.insert(0, pasta_app)

from blueprints.publicacoes import LIMITES_TAMANHO

# 1. Teste de Hashing de Palavras-Chave (Req. 2 e 4)
def test_seguranca_hash_password():
    password_original = "MinhaPasseSecreta123!"
    hash_gerada = generate_password_hash(password_original)
    
    assert hash_gerada != password_original
    assert check_password_hash(hash_gerada, password_original) is True
    assert check_password_hash(hash_gerada, "PasseErrada") is False

# 2. Teste de Regras de Limites de Upload (Req. 11)
def test_validacao_limites_tamanho():
    assert LIMITES_TAMANHO['jpeg'] == 10 * 1024 * 1024
    assert LIMITES_TAMANHO['png'] == 10 * 1024 * 1024
    assert LIMITES_TAMANHO['pdf'] == 50 * 1024 * 1024
    assert LIMITES_TAMANHO['mp3'] == 30 * 1024 * 1024
    assert LIMITES_TAMANHO['mp4'] == 200 * 1024 * 1024

# 3. Teste de Proteção Admin-Admin (Req. 3 e 8)
def test_regra_admin_nao_pode_sancionar_admin():
    papel_alvo = 'administrador'
    pode_sancionar = (papel_alvo != 'administrador')
    assert pode_sancionar is False

if __name__ == '__main__':
    print("A executar testes criticos de regras...")
    test_seguranca_hash_password()
    print("[OK] test_seguranca_hash_password")
    test_validacao_limites_tamanho()
    print("[OK] test_validacao_limites_tamanho")
    test_regra_admin_nao_pode_sancionar_admin()
    print("[OK] test_regra_admin_nao_pode_sancionar_admin")
    print("\nTodos os 3 testes passaram com sucesso!")
