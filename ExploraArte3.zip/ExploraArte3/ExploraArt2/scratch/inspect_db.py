import mysql.connector

conn = mysql.connector.connect(host='localhost', user='root', password='A12345-a', database='explora_art')
cur = conn.cursor(dictionary=True)
cur.execute('SELECT * FROM comunidades')
for c in cur.fetchall():
    print(c)
    cur.execute('SELECT * FROM comunidade_membros WHERE comunidade_id = %s', (c['id'],))
    print('  membros:', cur.fetchall())
conn.close()
