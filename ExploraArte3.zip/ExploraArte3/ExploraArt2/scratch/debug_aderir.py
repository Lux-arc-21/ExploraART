import sys, os
sys.path.insert(0, os.path.abspath('.'))
from app import app
import mysql.connector

client = app.test_client()
res = client.post('/login', data={'identificador': 'testeuser', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)
print('Login status:', res.status_code)
for l in res.data.decode('utf-8').splitlines():
    if 'Olá' in l or 'Ola' in l or 'alerta' in l:
        print(l)

conn = mysql.connector.connect(host='localhost', user='root', password='A12345-a', database='explora_art')
cur = conn.cursor(dictionary=True)
cur.execute("SELECT * FROM comunidades WHERE nome = 'Comunidade Notif Teste'")
com = cur.fetchone()
print('Comunidade:', com)
conn.close()

if com:
    res2 = client.post(f"/comunidade/{com['id']}/aderir", follow_redirects=True)
    print('Aderir status:', res2.status_code)
    for l in res2.data.decode('utf-8').splitlines():
        if 'alerta' in l:
            print(l)
