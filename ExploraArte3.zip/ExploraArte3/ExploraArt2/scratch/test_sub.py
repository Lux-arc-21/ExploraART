import sys, os, re
sys.path.insert(0, os.path.abspath('.'))
from app import app
import mysql.connector

client = app.test_client()
res_login = client.post('/login', data={'identificador': 'artista', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)

res_sub_post = client.post('/subscrever', data={'metodo_pagamento': 'multibanco'}, follow_redirects=True)
html = res_sub_post.data.decode('utf-8')
m = re.search(r'/confirmar-pagamento-sibs/(\d+)', html)
if m:
    sub_id = m.group(1)
    print('Sub id:', sub_id)
    res_conf = client.post(f'/confirmar-pagamento-sibs/{sub_id}', follow_redirects=True)
    print('Confirmacao status:', res_conf.status_code)
    for line in res_conf.data.decode('utf-8').splitlines():
        if 'alerta' in line:
            print(line)

    conn = mysql.connector.connect(host='localhost', user='root', password='A12345-a', database='explora_art')
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT id, username, papel FROM utilizadores WHERE username = 'artista'")
    print('Artista agora:', cur.fetchone())
    conn.close()
