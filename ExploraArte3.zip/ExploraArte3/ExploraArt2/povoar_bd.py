"""
Script para inicializar a base de dados com utilizadores e conteúdos de teste.
Executar: python povoar_bd.py
"""
import sys
import os

# Garantir imports corretos
pasta_atual = os.path.abspath(os.path.dirname(__file__))
if pasta_atual not in sys.path:
    sys.path.insert(0, pasta_atual)

from werkzeug.security import generate_password_hash
from database import obter_ligacao_bd

def povoar():
    ligacao = obter_ligacao_bd()
    if not ligacao:
        print("Erro: Nao foi possivel ligar ao MySQL.")
        return

    cursor = ligacao.cursor()
    print("A inserir dados de teste...")

    # 1. Utilizadores (Password padrao para todos: Teste1234!)
    hash_padrao = generate_password_hash("Teste1234!")
    
    utilizadores = [
        ('admin', 'admin@exploraart.pt', hash_padrao, 'administrador', True),
        ('subscrito', 'sub@exploraart.pt', hash_padrao, 'subscrito', True),
        ('artista', 'artista@exploraart.pt', hash_padrao, 'registado', True)
    ]

    for u in utilizadores:
        cursor.execute("""
            INSERT INTO utilizadores (username, email, password_hash, papel, email_confirmado, aceitou_termos_em)
            VALUES (%s, %s, %s, %s, %s, NOW())
            ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), papel = VALUES(papel), email_confirmado = TRUE
        """, u)

    # Obter IDs dos utilizadores
    cursor.execute("SELECT id, username FROM utilizadores")
    users = {row[1]: row[0] for row in cursor.fetchall()}

    for uid in users.values():
        cursor.execute("INSERT IGNORE INTO definicoes_conta (user_id) VALUES (%s)", (uid,))

    # 2. Tags
    tags = ['musica', 'rock', 'livros', 'ficcao', 'arte', 'fotografia', 'geral']
    for t in tags:
        cursor.execute("INSERT IGNORE INTO tags (nome) VALUES (%s)", (t,))

    cursor.execute("SELECT id, nome FROM tags")
    tags_dict = {row[1]: row[0] for row in cursor.fetchall()}

    # 3. Publicacoes de Exemplo
    pubs = [
        (users.get('artista'), 'texto', None, 'Bem-vindos a ExploraART!', 'Esta e a nossa primeira publicacao no feed geral.', None, ['geral']),
        (users.get('artista'), 'imagem', 'jpeg', 'Pintura a Oleo - Por do Sol', 'Obra criada com inspiracao no outono.', '/static/uploads/exemplo_arte.jpg', ['arte', 'fotografia']),
        (users.get('subscrito'), 'musica', 'mp3', 'Sinfonia Acustica no 1', 'Musica relaxante composta em estudio.', '/static/uploads/exemplo_musica.mp3', ['musica', 'rock']),
        (users.get('admin'), 'documento', 'pdf', 'Manual de Introducao as Artes', 'Um guia completo em PDF para novos artistas.', '/static/uploads/exemplo_livro.pdf', ['livros', 'ficcao'])
    ]

    for autor_id, tipo, formato, titulo, texto, url, tags_pub in pubs:
        if not autor_id:
            continue
        cursor.execute("""
            INSERT INTO publicacoes (autor_id, tipo_conteudo, formato_ficheiro, titulo, texto_corpo, url_cloud)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (autor_id, tipo, formato, titulo, texto, url))
        pub_id = cursor.lastrowid

        for tg in tags_pub:
            if tg in tags_dict:
                cursor.execute("INSERT IGNORE INTO publicacao_tags (publicacao_id, tag_id) VALUES (%s, %s)", (pub_id, tags_dict[tg]))

    ligacao.commit()
    cursor.close()
    ligacao.close()

    print("\n[OK] Base de dados povoada com sucesso!")
    print("Contas de teste criadas (todas com password: Teste1234!):")
    print(" - Administrador: admin / admin@exploraart.pt")
    print(" - Subscrito:     subscrito / sub@exploraart.pt")
    print(" - Registado:     artista / artista@exploraart.pt")

if __name__ == '__main__':
    povoar()
