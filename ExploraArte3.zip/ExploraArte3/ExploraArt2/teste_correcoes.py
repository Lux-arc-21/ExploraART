import mysql.connector
from app import app

# ─── Utilitario de limpeza da BD antes dos testes ───────────────────────────
def limpar_bd_teste():
    """Remove dados criados por testes anteriores para garantir estado limpo."""
    conn = mysql.connector.connect(
        host='localhost', user='root', password='A12345-a', database='explora_art'
    )
    cur = conn.cursor()
    # Limpa favoritos do artista (user_id=3) para evitar toggle indesejado
    cur.execute("DELETE FROM favoritos WHERE user_id = 3")
    # Limpa gostos criados em testes anteriores para pub 5
    cur.execute("DELETE FROM gostos WHERE user_id = 3 AND publicacao_id = 5")
    # Limpa playlists de teste anteriores
    cur.execute("DELETE FROM playlists WHERE user_id = 3 AND nome = 'Minha Playlist Rock'")
    conn.commit()
    cur.close()
    conn.close()

limpar_bd_teste()

client = app.test_client()

# ─── 1. Login como artista ───────────────────────────────────────────────────
res_log = client.post('/login', data={'identificador': 'artista', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)
assert res_log.status_code == 200

# ─── TEST 1: Criacao de Playlists (Bug #5) ──────────────────────────────────
res_pl = client.post('/playlists/criar', data={'nome': 'Minha Playlist Rock'}, follow_redirects=True)
assert res_pl.status_code == 200
assert 'Minha Playlist Rock' in res_pl.data.decode('utf-8')
print('[OK] TEST 1: Criacao de Playlists a funcionar')

# ─── TEST 2: Perfil apresenta publicacoes do utilizador (Bug #4) ─────────────
res_perf = client.get('/perfil?tab=publicacoes')
assert res_perf.status_code == 200
html_perf = res_perf.data.decode('utf-8')
# Publicacao id=5 tem titulo sem caracteres corrompidos
assert 'Bem-vindos a ExploraART!' in html_perf
print('[OK] TEST 2: Perfil apresenta publicacoes do utilizador')

# ─── TEST 3: Favoritos guardam e aparecem no separador do Perfil (Bug #8) ────
# Usa publicacao id=5 (do artista, titulo legivel)
res_fav = client.post('/publicacao/5/favorito')
assert res_fav.status_code == 200
fav_json = res_fav.get_json()
assert fav_json is not None, "Resposta nao e JSON"
assert fav_json.get('guardado') is True, f"Esperado guardado=True, obteve: {fav_json}"

res_perf_fav = client.get('/perfil?tab=favoritos')
assert res_perf_fav.status_code == 200
html_fav = res_perf_fav.data.decode('utf-8')
assert 'Bem-vindos a ExploraART!' in html_fav, "Publicacao favoritada nao aparece no perfil"
print('[OK] TEST 3: Favoritos guardam e aparecem no separador do Perfil')

# ─── TEST 4: Gostos persistentes no feed ao refrescar (Bug #1) ───────────────
res_like = client.post('/publicacao/5/gosto')
assert res_like.status_code == 200
like_json = res_like.get_json()
assert like_json is not None, "Resposta nao e JSON"
assert 'total' in like_json, f"Campo 'total' em falta: {like_json}"

res_feed = client.get('/')
html_feed = res_feed.data.decode('utf-8')
assert 'gostos-count-5' in html_feed, "ID de gostos nao encontrado no feed"
print('[OK] TEST 4: Gostos persistentes no feed ao refrescar')

# ─── TEST 5: Notificacoes geradas (Bug #7) ───────────────────────────────────
client.get('/logout')
client.post('/login', data={'identificador': 'subscrito', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)
res_com = client.post('/publicacao/5/comentar', data={'texto': 'Excelente trabalho artistico!'}, follow_redirects=True)
assert res_com.status_code == 200

# Artista deve ter notificacao nao lida
client.get('/logout')
client.post('/login', data={'identificador': 'artista', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)
res_notif = client.get('/api/notificacoes/nao-lidas')
assert res_notif.status_code == 200
notif_json = res_notif.get_json()
assert notif_json is not None
assert notif_json.get('total', 0) >= 1, f"Esperado >= 1 notificacao, obteve: {notif_json}"
print('[OK] TEST 5: Notificacoes geradas e detetadas com sucesso')

# ─── TEST 6: Denuncias visiveis no Painel de Moderacao (Bug #3) ──────────────
client.post('/publicacao/3/denunciar', data={'motivo': 'Conteudo improprio'}, follow_redirects=True)
client.get('/logout')
client.post('/login', data={'identificador': 'admin', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)
res_admin = client.get('/admin/denuncias')
assert res_admin.status_code == 200
html_admin = res_admin.data.decode('utf-8')
assert 'Painel de Modera' in html_admin
print('[OK] TEST 6: Denuncias visiveis no Painel de Moderacao')

# ─── TEST 7: Comunidades com links interativos (Bug #6) ──────────────────────
res_comun = client.get('/comunidades')
assert 'Entrar na Comunidade' in res_comun.data.decode('utf-8')
print('[OK] TEST 7: Comunidades interativas com links de entrada')

print('\nTODAS AS 8 CORRECOES FORAM TESTADAS E VALIDADAS COM SUCESSO A 100%!')
