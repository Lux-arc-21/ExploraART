import os
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify, current_app, send_file
from werkzeug.utils import secure_filename
from database import obter_ligacao_bd

publicacoes_bp = Blueprint('publicacoes', __name__)

LIMITES_TAMANHO = {
    'jpeg': 10 * 1024 * 1024,
    'png': 10 * 1024 * 1024,
    'pdf': 50 * 1024 * 1024,
    'mp3': 30 * 1024 * 1024,
    'mp4': 200 * 1024 * 1024
}

def obter_extensao(filename):
    return filename.rsplit('.', 1)[1].lower() if '.' in filename else ''

@publicacoes_bp.route('/criar-publicacao', methods=['GET', 'POST'])
def criar_publicacao():
    if not session.get('user_id'):
        flash('Precisa de ter sessão iniciada para publicar.', 'erro')
        return redirect(url_for('auth.iniciar_sessao'))

    if request.method == 'POST':
        titulo = request.form.get('titulo', '').strip()
        texto_corpo = request.form.get('texto_corpo', '').strip()
        tags_raw = request.form.get('tags', '').strip()
        ficheiro = request.files.get('ficheiro')

        if not tags_raw:
            flash('A publicação tem de ter pelo menos uma tag.', 'erro')
            return render_template('criar_publicacao.html')

        tipo_conteudo = 'texto'
        formato = None
        url_cloud = None
        tamanho_bytes = 0

        if ficheiro and ficheiro.filename != '':
            ext = obter_extensao(ficheiro.filename)
            if ext not in LIMITES_TAMANHO:
                flash('Formato não permitido. Formatos aceites: JPEG, PNG, PDF, MP3, MP4.', 'erro')
                return render_template('criar_publicacao.html')

            ficheiro.seek(0, os.SEEK_END)
            tamanho_bytes = ficheiro.tell()
            ficheiro.seek(0)

            if tamanho_bytes > LIMITES_TAMANHO[ext]:
                flash(f'O ficheiro excede o tamanho máximo permitido ({LIMITES_TAMANHO[ext] // (1024*1024)}MB).', 'erro')
                return render_template('criar_publicacao.html')

            formato = ext
            if ext in ['jpeg', 'png']:
                tipo_conteudo = 'imagem'
            elif ext == 'pdf':
                tipo_conteudo = 'documento'
            elif ext == 'mp3':
                tipo_conteudo = 'musica'
            elif ext == 'mp4':
                tipo_conteudo = 'video'

            nome_seguro = secure_filename(f"{session['user_id']}_{int(os.times().elapsed)}_{ficheiro.filename}")
            caminho = os.path.join(current_app.config['UPLOAD_FOLDER'], nome_seguro)
            ficheiro.save(caminho)
            url_cloud = f"/static/uploads/{nome_seguro}"

        ligacao = obter_ligacao_bd()
        cursor = ligacao.cursor()
        try:
            cursor.execute("""
                INSERT INTO publicacoes (autor_id, tipo_conteudo, formato_ficheiro, titulo, texto_corpo, url_cloud, tamanho_ficheiro)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (session['user_id'], tipo_conteudo, formato, titulo, texto_corpo, url_cloud, tamanho_bytes))
            publicacao_id = cursor.lastrowid

            # Inserir Tags
            tags_lista = list(set([t.strip().lower() for t in tags_raw.split(',') if t.strip()]))
            for tag_nome in tags_lista:
                cursor.execute("INSERT IGNORE INTO tags (nome) VALUES (%s)", (tag_nome,))
                cursor.execute("SELECT id FROM tags WHERE nome = %s", (tag_nome,))
                tag_id = cursor.fetchone()[0]
                cursor.execute("INSERT INTO publicacao_tags (publicacao_id, tag_id) VALUES (%s, %s)", (publicacao_id, tag_id))

            ligacao.commit()
            flash('Publicação realizada com sucesso!', 'sucesso')
            return redirect(url_for('pagina_feed'))
        except Exception as e:
            ligacao.rollback()
            flash('Erro ao guardar a publicação.', 'erro')
        finally:
            cursor.close()
            ligacao.close()

    return render_template('criar_publicacao.html')

@publicacoes_bp.route('/publicacao/<int:pub_id>')
def detalhe_publicacao(pub_id):
    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)
    user_id = session.get('user_id') or 0

    cursor.execute("""
        SELECT p.*, u.username AS autor_username, u.papel AS autor_papel,
               (SELECT COUNT(*) FROM gostos g WHERE g.publicacao_id = p.id) AS total_gostos,
               (SELECT COUNT(*) FROM gostos g WHERE g.publicacao_id = p.id AND g.user_id = %s) AS utilizador_gostou,
               (SELECT COUNT(*) FROM favoritos f WHERE f.publicacao_id = p.id AND f.user_id = %s) AS utilizador_favoritou
        FROM publicacoes p
        JOIN utilizadores u ON p.autor_id = u.id
        WHERE p.id = %s
    """, (user_id, user_id, pub_id))
    pub = cursor.fetchone()

    if not pub:
        cursor.close()
        ligacao.close()
        flash('Publicação não encontrada.', 'erro')
        return redirect(url_for('pagina_feed'))

    # Registar visualização acumulada se com sessão iniciada
    if session.get('user_id'):
        cursor.execute("""
            INSERT INTO visualizacoes (user_id, publicacao_id, segundos_totais)
            VALUES (%s, %s, 5)
            ON DUPLICATE KEY UPDATE segundos_totais = segundos_totais + 5
        """, (session['user_id'], pub_id))
        ligacao.commit()

    # Procurar Tags da publicação
    cursor.execute("""
        SELECT t.nome FROM tags t
        JOIN publicacao_tags pt ON pt.tag_id = t.id
        WHERE pt.publicacao_id = %s
    """, (pub_id,))
    tags = [t['nome'] for t in cursor.fetchall()]

    # Buscar comentários incluindo autor do comentário pai se for resposta
    cursor.execute("""
        SELECT c.*, u.username AS autor_username,
               u_pai.username AS pai_autor_username
        FROM comentarios c
        LEFT JOIN utilizadores u ON c.autor_id = u.id
        LEFT JOIN comentarios c_pai ON c.comentario_pai_id = c_pai.id
        LEFT JOIN utilizadores u_pai ON c_pai.autor_id = u_pai.id
        WHERE c.publicacao_id = %s
        ORDER BY c.data_comentario ASC
    """, (pub_id,))
    comentarios = cursor.fetchall()

    cursor.close()
    ligacao.close()
    return render_template('detalhe_publicacao.html', pub=pub, tags=tags, comentarios=comentarios)

@publicacoes_bp.route('/publicacao/<int:pub_id>/comentar', methods=['POST'])
def adicionar_comentario(pub_id):
    if not session.get('user_id'):
        flash('Precisa de iniciar sessão para comentar.', 'erro')
        return redirect(url_for('auth.iniciar_sessao'))

    texto = request.form.get('texto', '').strip()
    raw_pai = request.form.get('comentario_pai_id')
    pai_id = int(raw_pai) if raw_pai and raw_pai.strip().isdigit() else None

    if not texto:
        flash('O comentário não pode estar vazio.', 'erro')
        return redirect(url_for('publicacoes.detalhe_publicacao', pub_id=pub_id))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor()
    cursor.execute("""
        INSERT INTO comentarios (publicacao_id, autor_id, comentario_pai_id, texto)
        VALUES (%s, %s, %s, %s)
    """, (pub_id, session['user_id'], pai_id, texto))

    cursor.execute("SELECT autor_id, titulo FROM publicacoes WHERE id = %s", (pub_id,))
    pub = cursor.fetchone()

    # Se for resposta a outro comentário, notificar o autor do comentário original
    pai_autor_id = None
    if pai_id:
        cursor.execute("SELECT autor_id FROM comentarios WHERE id = %s", (pai_id,))
        com_pai = cursor.fetchone()
        if com_pai and com_pai[0]:
            pai_autor_id = com_pai[0]
            if pai_autor_id != session['user_id']:
                cursor.execute("""
                    INSERT INTO notificacoes (user_id, tipo, mensagem, link_referencia)
                    VALUES (%s, 'resposta', %s, %s)
                """, (pai_autor_id, f"{session['username']} respondeu ao seu comentário na publicação '{pub[1]}'.", f"/publicacao/{pub_id}"))

    # Notificar o autor da publicação (se não for o próprio nem já notificado como pai)
    if pub and pub[0] != session['user_id'] and pub[0] != pai_autor_id:
        cursor.execute("""
            INSERT INTO notificacoes (user_id, tipo, mensagem, link_referencia)
            VALUES (%s, 'comentario', %s, %s)
        """, (pub[0], f"{session['username']} comentou a sua publicação '{pub[1]}'.", f"/publicacao/{pub_id}"))

    ligacao.commit()
    cursor.close()
    ligacao.close()

    flash('Comentário submetido com sucesso!', 'sucesso')
    return redirect(url_for('publicacoes.detalhe_publicacao', pub_id=pub_id))

@publicacoes_bp.route('/publicacao/<int:pub_id>/gosto', methods=['POST'])
def alternar_gosto(pub_id):
    if not session.get('user_id'):
        return jsonify({'erro': 'Não autenticado'}), 401

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT * FROM gostos WHERE user_id = %s AND publicacao_id = %s", (session['user_id'], pub_id))
    existe = cursor.fetchone()

    if existe:
        cursor.execute("DELETE FROM gostos WHERE user_id = %s AND publicacao_id = %s", (session['user_id'], pub_id))
        gostou = False
    else:
        cursor.execute("INSERT INTO gostos (user_id, publicacao_id) VALUES (%s, %s)", (session['user_id'], pub_id))
        gostou = True

        cursor.execute("SELECT autor_id, titulo FROM publicacoes WHERE id = %s", (pub_id,))
        pub = cursor.fetchone()
        if pub and pub['autor_id'] != session['user_id']:
            cursor.execute("""
                INSERT INTO notificacoes (user_id, tipo, mensagem, link_referencia)
                VALUES (%s, 'gosto', %s, %s)
            """, (pub['autor_id'], f"{session['username']} gostou da sua publicação '{pub['titulo']}'.", f"/publicacao/{pub_id}"))

    cursor.execute("SELECT COUNT(*) AS total FROM gostos WHERE publicacao_id = %s", (pub_id,))
    total = cursor.fetchone()['total']

    ligacao.commit()
    cursor.close()
    ligacao.close()

    return jsonify({'gostou': gostou, 'total': total})

@publicacoes_bp.route('/publicacao/<int:pub_id>/download')
def descarregar_ficheiro(pub_id):
    if not session.get('user_id'):
        flash('Precisa de ter sessão iniciada.', 'erro')
        return redirect(url_for('auth.iniciar_sessao'))

    if session.get('papel') not in ['subscrito', 'administrador']:
        flash('O download de conteúdos é exclusivo para utilizadores Subscritos.', 'erro')
        return redirect(url_for('subscricao.subscrever'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)
    cursor.execute("SELECT url_cloud FROM publicacoes WHERE id = %s AND url_cloud IS NOT NULL", (pub_id,))
    pub = cursor.fetchone()

    if not pub:
        cursor.close()
        ligacao.close()
        flash('A publicação não possui ficheiro para download.', 'erro')
        return redirect(url_for('publicacoes.detalhe_publicacao', pub_id=pub_id))

    cursor.execute("INSERT IGNORE INTO downloads (user_id, publicacao_id) VALUES (%s, %s)", (session['user_id'], pub_id))
    ligacao.commit()
    cursor.close()
    ligacao.close()

    caminho_relativo = pub['url_cloud'].lstrip('/')
    caminho_abs = os.path.join(current_app.config['BASE_DIR'], caminho_relativo)
    return send_file(caminho_abs, as_attachment=True)

@publicacoes_bp.route('/publicacao/<int:pub_id>/denunciar', methods=['POST'])
def denunciar_publicacao(pub_id):
    if not session.get('user_id'):
        flash('Precisa de iniciar sessão para denunciar.', 'erro')
        return redirect(url_for('auth.iniciar_sessao'))

    motivo = request.form.get('motivo', '').strip()
    if not motivo:
        flash('Introduza o motivo da denúncia.', 'erro')
        return redirect(url_for('publicacoes.detalhe_publicacao', pub_id=pub_id))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT titulo FROM publicacoes WHERE id = %s", (pub_id,))
    pub = cursor.fetchone()

    try:
        cursor.execute("""
            INSERT INTO denuncias (reportador_id, publicacao_id, titulo_publicacao, motivo)
            VALUES (%s, %s, %s, %s)
        """, (session['user_id'], pub_id, pub['titulo'] if pub else '', motivo))
        ligacao.commit()
        flash('Denúncia submetida à moderação com sucesso.', 'sucesso')
    except Exception:
        ligacao.rollback()
        flash('Já denunciou esta publicação anteriormente.', 'erro')
    finally:
        cursor.close()
        ligacao.close()

    return redirect(url_for('publicacoes.detalhe_publicacao', pub_id=pub_id))

# Rota AJAX de Favoritos (Req. 10)
@publicacoes_bp.route('/publicacao/<int:pub_id>/favorito', methods=['POST'])
def alternar_favorito(pub_id):
    if not session.get('user_id'):
        return jsonify({'erro': 'Não autenticado'}), 401

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT * FROM favoritos WHERE user_id = %s AND publicacao_id = %s", (session['user_id'], pub_id))
    existe = cursor.fetchone()

    if existe:
        cursor.execute("DELETE FROM favoritos WHERE user_id = %s AND publicacao_id = %s", (session['user_id'], pub_id))
        guardado = False
    else:
        cursor.execute("INSERT INTO favoritos (user_id, publicacao_id) VALUES (%s, %s)", (session['user_id'], pub_id))
        guardado = True

    ligacao.commit()
    cursor.close()
    ligacao.close()
    return jsonify({'guardado': guardado})

# Rota para Filtrar por Tag (Req. 27)
@publicacoes_bp.route('/tag/<nome_tag>')
def publicacoes_por_tag(nome_tag):
    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)
    user_id = session.get('user_id') or 0

    cursor.execute("""
        SELECT p.*, u.username AS autor_username,
               (SELECT COUNT(*) FROM gostos g WHERE g.publicacao_id = p.id) AS total_gostos,
               (SELECT COUNT(*) FROM gostos g WHERE g.publicacao_id = p.id AND g.user_id = %s) AS utilizador_gostou,
               (SELECT COUNT(*) FROM favoritos f WHERE f.publicacao_id = p.id AND f.user_id = %s) AS utilizador_favoritou
        FROM publicacoes p
        JOIN publicacao_tags pt ON pt.publicacao_id = p.id
        JOIN tags t ON t.id = pt.tag_id
        JOIN utilizadores u ON u.id = p.autor_id
        WHERE t.nome = %s AND p.comunidade_id IS NULL
        ORDER BY p.data_publicacao DESC
    """, (user_id, user_id, nome_tag.lower()))
    publicacoes = cursor.fetchall()

    cursor.close()
    ligacao.close()
    return render_template('index.html', publicacoes=publicacoes, tag_ativa=nome_tag)

# Eliminar a própria publicação (Req. 25)
@publicacoes_bp.route('/publicacao/<int:pub_id>/eliminar', methods=['POST'])
def eliminar_publicacao(pub_id):
    user_id = session.get('user_id')
    papel = session.get('papel')
    if not user_id:
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)
    cursor.execute("SELECT autor_id FROM publicacoes WHERE id = %s", (pub_id,))
    pub = cursor.fetchone()

    if not pub:
        cursor.close()
        ligacao.close()
        flash('Publicação não encontrada.', 'erro')
        return redirect(url_for('pagina_feed'))

    if pub['autor_id'] == user_id or papel == 'administrador':
        cursor.execute("DELETE FROM publicacoes WHERE id = %s", (pub_id,))
        ligacao.commit()
        flash('Publicação eliminada com sucesso.', 'sucesso')
    else:
        flash('Não tem permissão para eliminar esta publicação.', 'erro')

    cursor.close()
    ligacao.close()
    return redirect(url_for('pagina_feed'))

# Eliminar comentário próprio (Req. 25)
@publicacoes_bp.route('/comentario/<int:com_id>/eliminar', methods=['POST'])
def eliminar_comentario(com_id):
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT autor_id, publicacao_id FROM comentarios WHERE id = %s", (com_id,))
    com = cursor.fetchone()

    if not com or com['autor_id'] != user_id:
        cursor.close()
        ligacao.close()
        flash('Ação não autorizada.', 'erro')
        return redirect(url_for('pagina_feed'))

    cursor.execute("SELECT COUNT(*) AS total_filhos FROM comentarios WHERE comentario_pai_id = %s", (com_id,))
    tem_filhos = cursor.fetchone()['total_filhos'] > 0

    if tem_filhos:
        cursor.execute("UPDATE comentarios SET eliminado = TRUE, texto = '[comentário eliminado]', autor_id = NULL WHERE id = %s", (com_id,))
    else:
        cursor.execute("DELETE FROM comentarios WHERE id = %s", (com_id,))

    ligacao.commit()
    cursor.close()
    ligacao.close()

    flash('Comentário eliminado.', 'sucesso')
    return redirect(url_for('publicacoes.detalhe_publicacao', pub_id=com['publicacao_id']))
