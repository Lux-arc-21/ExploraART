from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import check_password_hash
from database import obter_ligacao_bd

definicoes_bp = Blueprint('definicoes', __name__)

@definicoes_bp.route('/definicoes', methods=['GET', 'POST'])
def pagina_definicoes():
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    if request.method == 'POST':
        consentimento_feed = True if request.form.get('consentimento_feed') else False
        alto_contraste = True if request.form.get('alto_contraste') else False
        tamanho_texto = request.form.get('tamanho_texto', 'medio')

        cursor.execute("UPDATE utilizadores SET consentimento_feed = %s WHERE id = %s", (consentimento_feed, session['user_id']))
        cursor.execute("UPDATE definicoes_conta SET alto_contraste = %s, tamanho_texto = %s WHERE user_id = %s",
                       (alto_contraste, tamanho_texto, session['user_id']))
        ligacao.commit()
        flash('Definições atualizadas com sucesso.', 'sucesso')

    cursor.execute("""
        SELECT u.*, d.* FROM utilizadores u
        LEFT JOIN definicoes_conta d ON d.user_id = u.id
        WHERE u.id = %s
    """, (session['user_id'],))
    dados = cursor.fetchone()

    cursor.execute("""
        SELECT * FROM subscricoes 
        WHERE user_id = %s 
        ORDER BY id DESC LIMIT 1
    """, (session['user_id'],))
    subscricao = cursor.fetchone()

    cursor.close()
    ligacao.close()
    return render_template('definicoes.html', dados=dados, subscricao=subscricao)

@definicoes_bp.route('/eliminar-conta', methods=['POST'])
def eliminar_conta():
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    palavra_passe = request.form.get('palavra_passe', '')
    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT password_hash FROM utilizadores WHERE id = %s", (session['user_id'],))
    u = cursor.fetchone()

    if u and check_password_hash(u['password_hash'], palavra_passe):
        # Anonimizar registos de pagamentos mantendo dados contabilisticos
        cursor.execute("UPDATE pagamentos SET user_id = NULL WHERE user_id = %s", (session['user_id'],))
        
        # Eliminar utilizador (ON DELETE CASCADE trata das tabelas associadas)
        cursor.execute("DELETE FROM utilizadores WHERE id = %s", (session['user_id'],))
        ligacao.commit()
        
        session.clear()
        cursor.close()
        ligacao.close()
        flash('A sua conta foi eliminada permanentemente.', 'sucesso')
        return redirect(url_for('pagina_feed'))
    else:
        cursor.close()
        ligacao.close()
        flash('Palavra-passe incorreta. A conta não foi eliminada.', 'erro')
        return redirect(url_for('definicoes.pagina_definicoes'))

@definicoes_bp.route('/exportar-dados-pessoais')
def exportar_dados_pessoais():
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)
    cursor.execute("SELECT id, username, email, data_registo FROM utilizadores WHERE id = %s", (session['user_id'],))
    utilizador = cursor.fetchone()
    cursor.close()
    ligacao.close()

    return jsonify(utilizador)
