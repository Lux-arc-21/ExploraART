from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from database import obter_ligacao_bd

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/admin/denuncias')
def painel_denuncias():
    if session.get('papel') != 'administrador':
        flash('Acesso restrito a administradores.', 'erro')
        return redirect(url_for('pagina_feed'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)
    cursor.execute("""
        SELECT v.*, u.username AS autor_username, u.papel AS autor_papel,
               (SELECT GROUP_CONCAT(CONCAT('• ', u2.username, ': ', d2.motivo) SEPARATOR '<br>')
                FROM denuncias d2
                JOIN utilizadores u2 ON u2.id = d2.reportador_id
                WHERE d2.publicacao_id = v.publicacao_id AND d2.estado IN ('pendente', 'em_analise')
               ) AS motivos_detalhados
        FROM v_painel_denuncias v
        JOIN utilizadores u ON u.id = v.autor_id
    """)
    denuncias = cursor.fetchall()
    cursor.close()
    ligacao.close()
    return render_template('admin/denuncias.html', denuncias=denuncias)

@admin_bp.route('/admin/acao-denuncia', methods=['POST'])
def resolver_denuncia():
    if session.get('papel') != 'administrador':
        return redirect(url_for('pagina_feed'))

    pub_id = request.form.get('publicacao_id')
    acao = request.form.get('acao') # 'ignorar', 'eliminar_publicacao', 'suspender_autor', 'banir_autor'
    motivo = request.form.get('motivo', 'Violação dos Termos de Serviço')

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT autor_id FROM publicacoes WHERE id = %s", (pub_id,))
    pub = cursor.fetchone()
    autor_id = pub['autor_id'] if pub else None

    # Regra DoD: Administrador não pode sancionar outro administrador
    if autor_id and acao in ['suspender_autor', 'banir_autor']:
        cursor.execute("SELECT papel FROM utilizadores WHERE id = %s", (autor_id,))
        alvo = cursor.fetchone()
        if alvo and alvo['papel'] == 'administrador':
            cursor.close()
            ligacao.close()
            flash('Não é permitido suspender ou banir outro administrador.', 'erro')
            return redirect(url_for('admin.painel_denuncias'))

    if acao == 'eliminar_publicacao':
        cursor.execute("DELETE FROM publicacoes WHERE id = %s", (pub_id,))
    elif acao == 'suspender_autor' and autor_id:
        cursor.execute("UPDATE utilizadores SET estado = 'suspenso' WHERE id = %s", (autor_id,))
        cursor.execute("INSERT INTO sancoes (user_id, admin_id, tipo, motivo, data_fim) VALUES (%s, %s, 'suspensao', %s, DATE_ADD(NOW(), INTERVAL 7 DAY))",
                       (autor_id, session['user_id'], motivo))
    elif acao == 'banir_autor' and autor_id:
        cursor.execute("UPDATE utilizadores SET estado = 'banido' WHERE id = %s", (autor_id,))
        cursor.execute("INSERT INTO sancoes (user_id, admin_id, tipo, motivo) VALUES (%s, %s, 'banimento', %s)",
                       (autor_id, session['user_id'], motivo))

    cursor.execute("UPDATE denuncias SET estado = 'resolvida', acao_tomada = %s, resolvida_por = %s, data_resolucao = NOW() WHERE publicacao_id = %s",
                   (acao, session['user_id'], pub_id))
    
    ligacao.commit()
    cursor.close()
    ligacao.close()

    flash('Ação de moderação executada com sucesso.', 'sucesso')
    return redirect(url_for('admin.painel_denuncias'))
