from flask import Blueprint, render_template, request, session, jsonify, redirect, url_for, flash
from database import obter_ligacao_bd

musica_bp = Blueprint('musica', __name__)

@musica_bp.route('/playlists')
def gerir_playlists():
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)
    cursor.execute("SELECT * FROM playlists WHERE user_id = %s ORDER BY data_criacao DESC", (session['user_id'],))
    playlists = cursor.fetchall()
    cursor.close()
    ligacao.close()
    return render_template('playlists.html', playlists=playlists)

@musica_bp.route('/playlists/criar', methods=['POST'])
def criar_playlist():
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    nome = request.form.get('nome', '').strip()
    if not nome:
        flash('O nome da playlist é obrigatório.', 'erro')
        return redirect(url_for('musica.gerir_playlists'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor()
    try:
        cursor.execute("INSERT INTO playlists (user_id, nome) VALUES (%s, %s)", (session['user_id'], nome))
        ligacao.commit()
        flash('Playlist criada com sucesso!', 'sucesso')
    except Exception:
        ligacao.rollback()
        flash('Já tem uma playlist com esse nome.', 'erro')
    finally:
        cursor.close()
        ligacao.close()

    return redirect(url_for('musica.gerir_playlists'))

@musica_bp.route('/playlists/<int:pl_id>/eliminar', methods=['POST'])
def eliminar_playlist(pl_id):
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor()
    cursor.execute("DELETE FROM playlists WHERE id = %s AND user_id = %s", (pl_id, session['user_id']))
    ligacao.commit()
    cursor.close()
    ligacao.close()

    flash('Playlist eliminada com sucesso.', 'sucesso')
    return redirect(url_for('musica.gerir_playlists'))

@musica_bp.route('/playlist/<int:pl_id>/faixas')
def obter_faixas_playlist(pl_id):
    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT nome FROM playlists WHERE id = %s", (pl_id,))
    pl = cursor.fetchone()
    if not pl:
        cursor.close()
        ligacao.close()
        return jsonify({'faixas': [], 'nome': ''})

    cursor.execute("""
        SELECT p.id, p.titulo, p.url_cloud, pm.ordem
        FROM playlist_musicas pm
        JOIN publicacoes p ON p.id = pm.publicacao_id
        WHERE pm.playlist_id = %s
        ORDER BY pm.ordem ASC
    """, (pl_id,))
    faixas = cursor.fetchall()

    cursor.close()
    ligacao.close()
    return jsonify({'nome': pl['nome'], 'faixas': faixas})

@musica_bp.route('/sugerir-musica-livro/<int:pub_id>')
def sugerir_musica_livro(pub_id):
    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("""
        SELECT t.id FROM tags t
        JOIN publicacao_tags pt ON pt.tag_id = t.id
        WHERE pt.publicacao_id = %s
    """, (pub_id,))
    tag_ids = [r['id'] for r in cursor.fetchall()]

    if not tag_ids:
        cursor.close()
        ligacao.close()
        return jsonify({'sugestao': None})

    format_strings = ','.join(['%s'] * len(tag_ids))
    cursor.execute(f"""
        SELECT p.id, p.titulo, p.url_cloud 
        FROM publicacoes p
        JOIN publicacao_tags pt ON pt.publicacao_id = p.id
        WHERE pt.tag_id IN ({format_strings}) AND p.id != %s AND p.tipo_conteudo IN ('musica', 'documento')
        LIMIT 1
    """, tuple(tag_ids + [pub_id]))
    sugestao = cursor.fetchone()

    cursor.close()
    ligacao.close()
    return jsonify({'sugestao': sugestao})
