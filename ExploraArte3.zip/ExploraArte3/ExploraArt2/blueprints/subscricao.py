import random
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from database import obter_ligacao_bd

subscricao_bp = Blueprint('subscricao', __name__)
PRECO_MENSAL = 4.99

@subscricao_bp.route('/subscrever', methods=['GET', 'POST'])
def subscrever():
    if not session.get('user_id'):
        flash('Precisa de ter sessão iniciada para subscrever.', 'aviso')
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    # Verificar se o utilizador já é subscrito ou administrador
    cursor.execute("SELECT papel FROM utilizadores WHERE id = %s", (session['user_id'],))
    u = cursor.fetchone()
    papel_atual = u['papel'] if u else session.get('papel')

    cursor.execute("""
        SELECT * FROM subscricoes 
        WHERE user_id = %s AND estado = 'ativa' 
        ORDER BY id DESC LIMIT 1
    """, (session['user_id'],))
    sub_ativa = cursor.fetchone()

    if papel_atual in ['subscrito', 'administrador'] and sub_ativa:
        cursor.close()
        ligacao.close()
        return render_template('subscrever.html', preco=PRECO_MENSAL, ja_subscrito=True, subscricao=sub_ativa)

    if request.method == 'POST':
        metodo = request.form.get('metodo_pagamento')  # 'mb_way' ou 'multibanco'
        if not metodo:
            cursor.close()
            ligacao.close()
            flash('Por favor escolha um método de pagamento.', 'erro')
            return redirect(url_for('subscricao.subscrever'))

        cursor.execute("INSERT INTO subscricoes (user_id, metodo_pagamento, estado, renovacao_automatica) VALUES (%s, %s, 'pendente', TRUE)",
                       (session['user_id'], metodo))
        sub_id = cursor.lastrowid

        entidade = "12345" if metodo == 'multibanco' else None
        referencia = str(random.randint(100000000, 999999999)) if metodo == 'multibanco' else None
        ref_sibs = f"SIBS_{random.randint(100000, 999999)}"

        cursor.execute("""
            INSERT INTO pagamentos (subscricao_id, user_id, valor, metodo, estado, entidade, referencia_multibanco, referencia_sibs)
            VALUES (%s, %s, %s, %s, 'pendente', %s, %s, %s)
        """, (sub_id, session['user_id'], PRECO_MENSAL, metodo, entidade, referencia, ref_sibs))
        
        ligacao.commit()
        cursor.close()
        ligacao.close()

        flash('Subscrição iniciada! Simule a confirmação do pagamento SIBS para ativar o estatuto de Subscrito.', 'sucesso')
        return render_template('subscrever.html', preco=PRECO_MENSAL, pendente_id=sub_id, metodo=metodo, entidade=entidade, referencia=referencia)

    cursor.close()
    ligacao.close()
    return render_template('subscrever.html', preco=PRECO_MENSAL)

@subscricao_bp.route('/confirmar-pagamento-sibs/<int:sub_id>', methods=['POST'])
def confirmar_pagamento_sibs(sub_id):
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor()

    cursor.execute("UPDATE pagamentos SET estado = 'pago', data_pagamento = NOW() WHERE subscricao_id = %s", (sub_id,))
    cursor.execute("""
        UPDATE subscricoes 
        SET estado = 'ativa', renovacao_automatica = TRUE, data_inicio = NOW(), data_fim = DATE_ADD(NOW(), INTERVAL 1 MONTH) 
        WHERE id = %s
    """, (sub_id,))
    cursor.execute("UPDATE utilizadores SET papel = 'subscrito' WHERE id = %s", (session['user_id'],))

    # Notificar utilizador
    cursor.execute("""
        INSERT INTO notificacoes (user_id, tipo, mensagem, link_referencia)
        VALUES (%s, 'sistema', %s, %s)
    """, (session['user_id'], 'A sua subscrição ExploraART foi ativada com sucesso! Já pode descarregar ficheiros.', '/definicoes'))

    session['papel'] = 'subscrito'
    ligacao.commit()
    cursor.close()
    ligacao.close()

    flash('Pagamento confirmado com sucesso! Tornou-se um utilizador Subscrito (acesso a downloads e conteúdos offline).', 'sucesso')
    return redirect(url_for('definicoes.pagina_definicoes'))

@subscricao_bp.route('/cancelar-subscricao', methods=['POST'])
def cancelar_subscricao():
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor()
    cursor.execute("""
        UPDATE subscricoes 
        SET renovacao_automatica = FALSE, estado = 'cancelada' 
        WHERE user_id = %s AND estado = 'ativa'
    """, (session['user_id'],))

    cursor.execute("""
        INSERT INTO notificacoes (user_id, tipo, mensagem, link_referencia)
        VALUES (%s, 'sistema', %s, %s)
    """, (session['user_id'], 'A renovação automática da sua subscrição foi desativada. Terá acesso até ao final do período pago.', '/definicoes'))

    ligacao.commit()
    cursor.close()
    ligacao.close()

    flash('A renovação automática foi cancelada. Terá acesso a todas as funcionalidades de subscrito até à data de expiração.', 'sucesso')
    return redirect(url_for('definicoes.pagina_definicoes'))
