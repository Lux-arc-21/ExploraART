from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import secrets
from database import obter_ligacao_bd

auth_bp = Blueprint('auth', __name__)

def verificar_sancao(user_id):
    """Verifica se o utilizador tem alguma sanção ativa (suspensão ou banimento)."""
    ligacao = obter_ligacao_bd()
    if not ligacao:
        return 'ativo', None
    cursor = ligacao.cursor(dictionary=True)
    
    cursor.execute("SELECT estado FROM utilizadores WHERE id = %s", (user_id,))
    utilizador = cursor.fetchone()
    
    if not utilizador:
        cursor.close()
        ligacao.close()
        return 'inexistente', None
        
    if utilizador['estado'] == 'banido':
        cursor.close()
        ligacao.close()
        return 'banido', 'A sua conta foi banida permanentemente por incumprimento dos termos.'
        
    if utilizador['estado'] == 'suspenso':
        cursor.execute("""
            SELECT motivo, data_fim FROM sancoes 
            WHERE user_id = %s AND tipo = 'suspensao' 
            ORDER BY data_inicio DESC LIMIT 1
        """, (user_id,))
        sancao = cursor.fetchone()
        
        if sancao and sancao['data_fim'] and sancao['data_fim'] <= datetime.now():
            # A suspensão expirou automaticamente
            cursor.execute("UPDATE utilizadores SET estado = 'ativo' WHERE id = %s", (user_id,))
            ligacao.commit()
            cursor.close()
            ligacao.close()
            return 'ativo', None
        else:
            msg = f"Conta suspensa até {sancao['data_fim'].strftime('%Y-%m-%d %H:%M') if sancao and sancao['data_fim'] else 'data indefinida'}. Motivo: {sancao['motivo'] if sancao else 'Não especificado'}"
            cursor.close()
            ligacao.close()
            return 'suspenso', msg

    cursor.close()
    ligacao.close()
    return 'ativo', None

@auth_bp.route('/login', methods=['GET', 'POST'])
def iniciar_sessao():
    if request.method == 'POST':
        identificador = request.form.get('identificador', '').strip()
        palavra_passe = request.form.get('palavra_passe', '')

        ligacao = obter_ligacao_bd()
        if not ligacao:
            flash('Erro de ligação à base de dados.', 'erro')
            return render_template('login.html')

        cursor = ligacao.cursor(dictionary=True)
        cursor.execute("SELECT * FROM utilizadores WHERE username = %s OR email = %s", (identificador, identificador))
        utilizador = cursor.fetchone()

        if utilizador:
            # Verificar bloqueio temporário por tentativas falhadas
            if utilizador['bloqueado_ate'] and utilizador['bloqueado_ate'] > datetime.now():
                minutos_restantes = int((utilizador['bloqueado_ate'] - datetime.now()).total_seconds() // 60) + 1
                flash(f'Conta bloqueada temporariamente. Tente novamente daqui a {minutos_restantes} minutos.', 'erro')
                cursor.close()
                ligacao.close()
                return render_template('login.html')

            # Verificar se a conta está confirmada
            if not utilizador['email_confirmado']:
                flash('O email ainda não foi confirmado. Por favor confirme através do link enviado.', 'erro')
                cursor.close()
                ligacao.close()
                return render_template('login.html')

            # Verificar sanções
            estado_sancao, msg_sancao = verificar_sancao(utilizador['id'])
            if estado_sancao in ['banido', 'suspenso']:
                flash(msg_sancao, 'erro')
                cursor.close()
                ligacao.close()
                return render_template('login.html')

            # Validação da palavra-passe
            if check_password_hash(utilizador['password_hash'], palavra_passe):
                cursor.execute("UPDATE utilizadores SET tentativas_falhadas = 0, bloqueado_ate = NULL WHERE id = %s", (utilizador['id'],))
                ligacao.commit()

                session['user_id'] = utilizador['id']
                session['username'] = utilizador['username']
                session['papel'] = utilizador['papel']

                cursor.close()
                ligacao.close()
                return redirect(url_for('pagina_feed'))
            else:
                novas_falhas = utilizador['tentativas_falhadas'] + 1
                bloqueio_ate = datetime.now() + timedelta(minutes=15) if novas_falhas >= 5 else None
                cursor.execute("UPDATE utilizadores SET tentativas_falhadas = %s, bloqueado_ate = %s WHERE id = %s", (novas_falhas, bloqueio_ate, utilizador['id']))
                ligacao.commit()

                if novas_falhas >= 5:
                    flash('Atingiu 5 tentativas falhadas. A sua conta foi bloqueada por 15 minutos.', 'erro')
                else:
                    flash(f'Credenciais inválidas. Tentativa {novas_falhas} de 5.', 'erro')
        else:
            flash('Utilizador não encontrado ou credenciais incorretas.', 'erro')

        cursor.close()
        ligacao.close()

    return render_template('login.html')

@auth_bp.route('/registar', methods=['GET', 'POST'])
def criar_conta():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        palavra_passe = request.form.get('palavra_passe', '')
        confirmar_palavra_passe = request.form.get('confirmar_palavra_passe', '')
        termos = request.form.get('termos')

        if not termos:
            flash('Tem de aceitar obrigatoriamente os termos de serviço e a política de privacidade.', 'erro')
            return render_template('registar.html')

        if len(username) < 3 or len(username) > 50:
            flash('O nome de utilizador deve ter entre 3 e 50 caracteres.', 'erro')
            return render_template('registar.html')

        if len(palavra_passe) < 8 or palavra_passe != confirmar_palavra_passe:
            flash('A palavra-passe deve ter pelo menos 8 caracteres e coincidir com a confirmação.', 'erro')
            return render_template('registar.html')

        password_hash = generate_password_hash(palavra_passe)
        ligacao = obter_ligacao_bd()
        if not ligacao:
            flash('Erro ao aceder à base de dados.', 'erro')
            return render_template('registar.html')

        cursor = ligacao.cursor()
        try:
            # Em ambiente de produção o email_confirmado é False e envia-se um link.
            # Para testes funcionais rápidos colocamos True ou facultamos o botão de simulação.
            cursor.execute("""
                INSERT INTO utilizadores (username, email, password_hash, email_confirmado, aceitou_termos_em)
                VALUES (%s, %s, %s, TRUE, NOW())
            """, (username, email, password_hash))
            user_id = cursor.lastrowid

            cursor.execute("INSERT INTO definicoes_conta (user_id) VALUES (%s)", (user_id,))
            ligacao.commit()

            flash('Conta criada com sucesso! Já pode iniciar sessão.', 'sucesso')
            return redirect(url_for('auth.iniciar_sessao'))
        except Exception as e:
            ligacao.rollback()
            flash('O nome de utilizador ou o email já estão registados.', 'erro')
        finally:
            cursor.close()
            ligacao.close()

    return render_template('registar.html')

@auth_bp.route('/recuperar-acesso', methods=['GET', 'POST'])
def recuperar_acesso():
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        ligacao = obter_ligacao_bd()
        cursor = ligacao.cursor(dictionary=True)

        cursor.execute("SELECT id FROM utilizadores WHERE email = %s", (email,))
        utilizador = cursor.fetchone()

        if utilizador:
            token = secrets.token_hex(32)
            token_hash = generate_password_hash(token)
            expiracao = datetime.now() + timedelta(hours=1)

            cursor.execute("UPDATE utilizadores SET token_recuperacao = %s, expiracao_token = %s WHERE id = %s",
                           (token_hash, expiracao, utilizador['id']))
            ligacao.commit()
            flash(f'Simulação de Email enviado com Token de Recuperação: {token}', 'sucesso')
        else:
            flash('Se o email existir na plataforma, enviámos as instruções de recuperação.', 'sucesso')

        cursor.close()
        ligacao.close()
        return redirect(url_for('auth.iniciar_sessao'))

    return render_template('recuperar_acesso.html')

@auth_bp.route('/redefinir-password/<token>', methods=['GET', 'POST'])
def redefinir_password(token):
    if request.method == 'POST':
        palavra_passe = request.form.get('palavra_passe', '')
        confirmar = request.form.get('confirmar_palavra_passe', '')

        if len(palavra_passe) < 8 or palavra_passe != confirmar:
            flash('Palavra-passe inválida ou não coincidente.', 'erro')
            return render_template('redefinir_password.html', token=token)

        ligacao = obter_ligacao_bd()
        cursor = ligacao.cursor(dictionary=True)

        cursor.execute("SELECT id, token_recuperacao, expiracao_token FROM utilizadores WHERE expiracao_token > NOW()")
        utilizadores = cursor.fetchall()

        utilizador_valido = None
        for u in utilizadores:
            if u['token_recuperacao'] and check_password_hash(u['token_recuperacao'], token):
                utilizador_valido = u
                break

        if utilizador_valido:
            nova_hash = generate_password_hash(palavra_passe)
            cursor.execute("UPDATE utilizadores SET password_hash = %s, token_recuperacao = NULL, expiracao_token = NULL WHERE id = %s",
                           (nova_hash, utilizador_valido['id']))
            ligacao.commit()
            flash('Palavra-passe redefinida com sucesso!', 'sucesso')
            cursor.close()
            ligacao.close()
            return redirect(url_for('auth.iniciar_sessao'))
        else:
            flash('Token inválido ou expirado.', 'erro')
            cursor.close()
            ligacao.close()

    return render_template('redefinir_password.html', token=token)

@auth_bp.route('/logout')
def terminar_sessao():
    session.clear()
    return redirect(url_for('pagina_feed'))