from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from database import obter_ligacao_bd

comunidades_bp = Blueprint('comunidades', __name__)

@comunidades_bp.route('/comunidades')
def listar_comunidades():
    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)
    cursor.execute("SELECT * FROM comunidades ORDER BY data_criacao DESC")
    lista = cursor.fetchall()
    cursor.close()
    ligacao.close()
    return render_template('comunidades.html', comunidades=lista)

@comunidades_bp.route('/criar-comunidade', methods=['POST'])
def criar_comunidade():
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    nome = request.form.get('nome', '').strip()
    descricao = request.form.get('descricao', '').strip()
    tipo = request.form.get('tipo', 'publica')

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor()
    try:
        cursor.execute("INSERT INTO comunidades (criador_id, nome, descricao, tipo) VALUES (%s, %s, %s, %s)",
                       (session['user_id'], nome, descricao, tipo))
        com_id = cursor.lastrowid
        cursor.execute("INSERT INTO comunidade_membros (comunidade_id, user_id, papel, estado, data_adesao) VALUES (%s, %s, 'administrador', 'ativo', NOW())",
                       (com_id, session['user_id']))
        ligacao.commit()
        flash('Comunidade criada com sucesso!', 'sucesso')
    except Exception:
        ligacao.rollback()
        flash('Erro ao criar a comunidade. O nome poderá já existir.', 'erro')
    finally:
        cursor.close()
        ligacao.close()

    return redirect(url_for('comunidades.listar_comunidades'))


@comunidades_bp.route('/comunidade/<int:com_id>')
def detalhe_comunidade(com_id):
    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT * FROM comunidades WHERE id = %s", (com_id,))
    comunidade = cursor.fetchone()
    if not comunidade:
        cursor.close()
        ligacao.close()
        flash('Comunidade não encontrada.', 'erro')
        return redirect(url_for('comunidades.listar_comunidades'))

    user_id = session.get('user_id')
    estado_membro = None
    e_administrador = False

    if user_id:
        cursor.execute("SELECT papel, estado FROM comunidade_membros WHERE comunidade_id = %s AND user_id = %s", (com_id, user_id))
        reg = cursor.fetchone()
        if reg:
            estado_membro = reg['estado']
            e_administrador = (reg['papel'] == 'administrador')
        if comunidade.get('criador_id') == user_id:
            e_administrador = True

    pedidos_pendentes = []
    if e_administrador:
        cursor.execute("""
            SELECT cm.user_id, u.username, cm.data_pedido
            FROM comunidade_membros cm
            JOIN utilizadores u ON u.id = cm.user_id
            WHERE cm.comunidade_id = %s AND cm.estado = 'pendente'
        """, (com_id,))
        pedidos_pendentes = cursor.fetchall()

    cursor.execute("""
        SELECT p.*, u.username AS autor_username
        FROM publicacoes p
        JOIN utilizadores u ON p.autor_id = u.id
        WHERE p.comunidade_id = %s
        ORDER BY p.data_publicacao DESC
    """, (com_id,))
    publicacoes = cursor.fetchall()

    cursor.close()
    ligacao.close()

    return render_template('detalhe_comunidade.html',
                           comunidade=comunidade,
                           estado_membro=estado_membro,
                           e_administrador=e_administrador,
                           pedidos_pendentes=pedidos_pendentes,
                           publicacoes=publicacoes)

@comunidades_bp.route('/comunidade/<int:com_id>/aderir', methods=['POST'])
def aderir_comunidade(com_id):
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    user_id = session['user_id']
    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT id, nome, tipo, criador_id FROM comunidades WHERE id = %s", (com_id,))
    com = cursor.fetchone()
    if not com:
        cursor.close()
        ligacao.close()
        return redirect(url_for('comunidades.listar_comunidades'))

    estado = 'ativo' if com['tipo'] == 'publica' else 'pendente'
    data_adesao = 'NOW()' if estado == 'ativo' else 'NULL'

    cursor.execute(f"""
        INSERT INTO comunidade_membros (comunidade_id, user_id, papel, estado, data_adesao)
        VALUES (%s, %s, 'membro', %s, {data_adesao})
        ON DUPLICATE KEY UPDATE estado = VALUES(estado)
    """, (com_id, user_id, estado))

    # Obter nome do utilizador requerente
    cursor.execute("SELECT username FROM utilizadores WHERE id = %s", (user_id,))
    req_user = cursor.fetchone()
    nome_requerente = req_user['username'] if req_user else session.get('username', 'Um utilizador')

    # Obter administradores da comunidade para notificar
    cursor.execute("SELECT user_id FROM comunidade_membros WHERE comunidade_id = %s AND papel = 'administrador'", (com_id,))
    admins = cursor.fetchall()
    admin_ids = {a['user_id'] for a in admins if a.get('user_id')}
    if com.get('criador_id'):
        admin_ids.add(com['criador_id'])
    admin_ids.discard(user_id)

    if estado == 'pendente':
        # Notificar os administradores do pedido de adesao
        for admin_id in admin_ids:
            cursor.execute("""
                INSERT INTO notificacoes (user_id, tipo, mensagem, link_referencia)
                VALUES (%s, 'sistema', %s, %s)
            """, (admin_id, f"O utilizador {nome_requerente} pediu para aderir à comunidade '{com['nome']}'.", f"/comunidade/{com_id}"))
    else:
        # Notificar os administradores de nova entrada direta
        for admin_id in admin_ids:
            cursor.execute("""
                INSERT INTO notificacoes (user_id, tipo, mensagem, link_referencia)
                VALUES (%s, 'sistema', %s, %s)
            """, (admin_id, f"O utilizador {nome_requerente} aderiu à comunidade '{com['nome']}'.", f"/comunidade/{com_id}"))

    ligacao.commit()
    cursor.close()
    ligacao.close()

    flash('Pedido processado com sucesso!', 'sucesso')
    return redirect(url_for('comunidades.detalhe_comunidade', com_id=com_id))

@comunidades_bp.route('/comunidade/<int:com_id>/aprovar/<int:user_id>', methods=['POST'])
def aprovar_membro(com_id, user_id):
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT id, nome, criador_id FROM comunidades WHERE id = %s", (com_id,))
    com_info = cursor.fetchone()
    com_nome = com_info['nome'] if com_info else 'a comunidade'

    # Verificar se quem aprova é admin da comunidade ou criador
    cursor.execute("SELECT papel FROM comunidade_membros WHERE comunidade_id = %s AND user_id = %s", (com_id, session['user_id']))
    membro = cursor.fetchone()
    e_admin = (membro and membro['papel'] == 'administrador') or (com_info and com_info['criador_id'] == session['user_id'])
    if not e_admin:
        cursor.close()
        ligacao.close()
        flash('Apenas administradores da comunidade podem aprovar membros.', 'erro')
        return redirect(url_for('comunidades.detalhe_comunidade', com_id=com_id))

    cursor.execute("""
        UPDATE comunidade_membros 
        SET estado = 'ativo', data_adesao = NOW() 
        WHERE comunidade_id = %s AND user_id = %s
    """, (com_id, user_id))

    cursor.execute("""
        INSERT INTO notificacoes (user_id, tipo, mensagem, link_referencia)
        VALUES (%s, 'sistema', %s, %s)
    """, (user_id, f"O seu pedido de adesão à comunidade '{com_nome}' foi aprovado!", f"/comunidade/{com_id}"))

    ligacao.commit()
    cursor.close()
    ligacao.close()

    flash('Membro aprovado com sucesso!', 'sucesso')
    return redirect(url_for('comunidades.detalhe_comunidade', com_id=com_id))

@comunidades_bp.route('/comunidade/<int:com_id>/publicar', methods=['POST'])
def publicar_forum(com_id):
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    titulo = request.form.get('titulo', '').strip()
    texto_corpo = request.form.get('texto_corpo', '').strip()

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor()
    cursor.execute("""
        INSERT INTO publicacoes (autor_id, comunidade_id, tipo_conteudo, titulo, texto_corpo)
        VALUES (%s, %s, 'texto', %s, %s)
    """, (session['user_id'], com_id, titulo, texto_corpo))
    ligacao.commit()
    cursor.close()
    ligacao.close()

    flash('Publicação enviada para o fórum da comunidade!', 'sucesso')
    return redirect(url_for('comunidades.detalhe_comunidade', com_id=com_id))
