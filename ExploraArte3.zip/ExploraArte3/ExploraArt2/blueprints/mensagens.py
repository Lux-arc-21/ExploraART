from flask import Blueprint, render_template, request, redirect, url_for, session, jsonify, flash
from datetime import datetime
from database import obter_ligacao_bd

mensagens_bp = Blueprint('mensagens', __name__)

def obter_contactos_e_utilizadores(cursor, user_id):
    """Auxiliar para obter a lista de contactos com contagem de não lidas e utilizadores disponíveis."""
    cursor.execute("""
        SELECT DISTINCT u.id, u.username, u.papel,
               (SELECT COUNT(*) FROM mensagens_diretas WHERE remetente_id = u.id AND destinatario_id = %s AND data_leitura IS NULL) AS msgs_nao_lidas
        FROM utilizadores u
        JOIN mensagens_diretas m ON (m.remetente_id = u.id OR m.destinatario_id = u.id)
        WHERE (m.remetente_id = %s OR m.destinatario_id = %s) AND u.id != %s
        ORDER BY (msgs_nao_lidas > 0) DESC, u.username ASC
    """, (user_id, user_id, user_id, user_id))
    contactos = cursor.fetchall()

    cursor.execute("""
        SELECT id, username, papel
        FROM utilizadores
        WHERE id != %s AND estado = 'ativo'
        ORDER BY username ASC
        LIMIT 100
    """, (user_id,))
    todos_utilizadores = cursor.fetchall()

    return contactos, todos_utilizadores

@mensagens_bp.route('/api/mensagens/nao-lidas')
def api_mensagens_nao_lidas():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'total_conversas': 0})

    ligacao = obter_ligacao_bd()
    if not ligacao:
        return jsonify({'total_conversas': 0})

    cursor = ligacao.cursor(dictionary=True)
    cursor.execute("""
        SELECT COUNT(DISTINCT remetente_id) AS total
        FROM mensagens_diretas
        WHERE destinatario_id = %s AND data_leitura IS NULL
    """, (user_id,))
    res = cursor.fetchone()
    total = res['total'] if res else 0

    cursor.close()
    ligacao.close()
    return jsonify({'total_conversas': total})

@mensagens_bp.route('/mensagens')
def caixa_mensagens():
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)
    contactos, todos_utilizadores = obter_contactos_e_utilizadores(cursor, session['user_id'])
    cursor.close()
    ligacao.close()

    return render_template('mensagens.html', contactos=contactos, todos_utilizadores=todos_utilizadores)

@mensagens_bp.route('/mensagens/<int:outro_id>', methods=['GET', 'POST'])
def conversa(outro_id):
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    if outro_id == session['user_id']:
        flash('Não pode enviar mensagens a si próprio.', 'aviso')
        return redirect(url_for('mensagens.caixa_mensagens'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT id, username, papel FROM utilizadores WHERE id = %s AND estado = 'ativo'", (outro_id,))
    outro_utilizador = cursor.fetchone()

    if not outro_utilizador:
        cursor.close()
        ligacao.close()
        flash('Utilizador não encontrado.', 'erro')
        return redirect(url_for('mensagens.caixa_mensagens'))

    if request.method == 'POST':
        texto = request.form.get('texto', '').strip()
        if texto:
            cursor.execute("""
                INSERT INTO mensagens_diretas (remetente_id, destinatario_id, texto)
                VALUES (%s, %s, %s)
            """, (session['user_id'], outro_id, texto))

            # Notificar destinatário
            cursor.execute("""
                INSERT INTO notificacoes (user_id, tipo, mensagem, link_referencia)
                VALUES (%s, 'sistema', %s, %s)
            """, (outro_id, f"Recebeu uma nova mensagem de {session['username']}.", f"/mensagens/{session['user_id']}"))

            ligacao.commit()
            cursor.close()
            ligacao.close()
            return redirect(url_for('mensagens.conversa', outro_id=outro_id))

    # Marcar mensagens do outro utilizador como lidas imediatamente ao abrir a conversa
    cursor.execute("""
        UPDATE mensagens_diretas 
        SET data_leitura = NOW() 
        WHERE destinatario_id = %s AND remetente_id = %s AND data_leitura IS NULL
    """, (session['user_id'], outro_id))
    ligacao.commit()

    # Buscar histórico da conversa
    cursor.execute("""
        SELECT m.*, u.username AS remetente_username
        FROM mensagens_diretas m
        JOIN utilizadores u ON u.id = m.remetente_id
        WHERE (m.remetente_id = %s AND m.destinatario_id = %s) 
           OR (m.remetente_id = %s AND m.destinatario_id = %s)
        ORDER BY m.data_envio ASC
    """, (session['user_id'], outro_id, outro_id, session['user_id']))
    mensagens = cursor.fetchall()

    contactos, todos_utilizadores = obter_contactos_e_utilizadores(cursor, session['user_id'])

    cursor.close()
    ligacao.close()

    return render_template('mensagens.html',
                           mensagens=mensagens,
                           outro_id=outro_id,
                           outro_utilizador=outro_utilizador,
                           contactos=contactos,
                           todos_utilizadores=todos_utilizadores)
