from flask import Blueprint, render_template, session, redirect, url_for, jsonify
from database import obter_ligacao_bd

notificacoes_bp = Blueprint('notificacoes', __name__)

@notificacoes_bp.route('/api/notificacoes/nao-lidas')
def notificacoes_nao_lidas():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'total': 0, 'itens': []})

    ligacao = obter_ligacao_bd()
    if not ligacao:
        return jsonify({'total': 0, 'itens': []})

    cursor = ligacao.cursor(dictionary=True)
    cursor.execute("""
        SELECT id, mensagem, link_referencia, data_notificacao 
        FROM notificacoes 
        WHERE user_id = %s AND lida = FALSE 
        ORDER BY data_notificacao DESC LIMIT 10
    """, (user_id,))
    itens = cursor.fetchall()
    
    cursor.close()
    ligacao.close()

    return jsonify({'total': len(itens), 'itens': itens})

@notificacoes_bp.route('/notificacoes')
def listar_notificacoes():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)
    cursor.execute("""
        SELECT * FROM notificacoes 
        WHERE user_id = %s 
        ORDER BY data_notificacao DESC
    """, (user_id,))
    lista = cursor.fetchall()

    cursor.close()
    ligacao.close()
    return render_template('notificacoes.html', notificacoes=lista)

@notificacoes_bp.route('/notificacoes/<int:notif_id>/abrir')
def abrir_notificacao(notif_id):
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('auth.iniciar_sessao'))

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT link_referencia FROM notificacoes WHERE id = %s AND user_id = %s", (notif_id, user_id))
    notif = cursor.fetchone()

    cursor.execute("UPDATE notificacoes SET lida = TRUE WHERE id = %s AND user_id = %s", (notif_id, user_id))
    ligacao.commit()
    cursor.close()
    ligacao.close()

    if notif and notif['link_referencia']:
        return redirect(notif['link_referencia'])
    return redirect(url_for('notificacoes.listar_notificacoes'))