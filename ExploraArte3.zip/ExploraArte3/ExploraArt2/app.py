from datetime import datetime
from flask import Flask, render_template, request, session, redirect, url_for, flash
from config import Configuracao
from database import obter_ligacao_bd

from blueprints.auth import auth_bp
from blueprints.publicacoes import publicacoes_bp
from blueprints.subscricao import subscricao_bp
from blueprints.comunidades import comunidades_bp
from blueprints.mensagens import mensagens_bp
from blueprints.musica import musica_bp
from blueprints.admin import admin_bp
from blueprints.definicoes import definicoes_bp
from blueprints.notificacoes import notificacoes_bp

app = Flask(__name__)
app.config.from_object(Configuracao)

# Registo dos Módulos (Blueprints)
app.register_blueprint(auth_bp)
app.register_blueprint(publicacoes_bp)
app.register_blueprint(subscricao_bp)
app.register_blueprint(comunidades_bp)
app.register_blueprint(mensagens_bp)
app.register_blueprint(musica_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(definicoes_bp)
app.register_blueprint(notificacoes_bp)

# ---------------------------------------------------------------------
# Processador de Contexto: Contadores Globais (Mensagens e Notificações)
# ---------------------------------------------------------------------
@app.context_processor
def injetar_contadores_globais():
    user_id = session.get('user_id')
    if not user_id:
        return {
            'total_notificacoes_nao_lidas': 0,
            'total_conversas_nao_lidas': 0
        }

    ligacao = obter_ligacao_bd()
    if not ligacao:
        return {
            'total_notificacoes_nao_lidas': 0,
            'total_conversas_nao_lidas': 0
        }

    cursor = ligacao.cursor(dictionary=True)
    # Total de notificações não lidas
    cursor.execute("SELECT COUNT(*) AS total FROM notificacoes WHERE user_id = %s AND lida = FALSE", (user_id,))
    res_notif = cursor.fetchone()
    total_notif = res_notif['total'] if res_notif else 0

    # Total de conversas com mensagens por ler (número de conversas distintas)
    cursor.execute("""
        SELECT COUNT(DISTINCT remetente_id) AS total 
        FROM mensagens_diretas 
        WHERE destinatario_id = %s AND data_leitura IS NULL
    """, (user_id,))
    res_msgs = cursor.fetchone()
    total_msgs = res_msgs['total'] if res_msgs else 0

    cursor.close()
    ligacao.close()

    return {
        'total_notificacoes_nao_lidas': total_notif,
        'total_conversas_nao_lidas': total_msgs
    }

# ---------------------------------------------------------------------
# Middleware: Verificação de Sanção em Cada Pedido (DoD Req. 3 e 8)
# ---------------------------------------------------------------------
@app.before_request
def verificar_sancao_global():
    user_id = session.get('user_id')
    if not user_id:
        return

    # Rotas estáticas ou de logout não precisam de verificação
    if request.endpoint in ['auth.terminar_sessao', 'static']:
        return

    ligacao = obter_ligacao_bd()
    if not ligacao:
        return

    cursor = ligacao.cursor(dictionary=True)
    cursor.execute("SELECT estado, papel FROM utilizadores WHERE id = %s", (user_id,))
    u = cursor.fetchone()

    if not u or u['estado'] == 'banido':
        cursor.close()
        ligacao.close()
        session.clear()
        flash('A sua conta foi banida permanentemente por incumprimento dos termos.', 'erro')
        return redirect(url_for('auth.iniciar_sessao'))

    if u['estado'] == 'suspenso':
        cursor.execute("""
            SELECT motivo, data_fim FROM sancoes 
            WHERE user_id = %s AND tipo = 'suspensao' 
            ORDER BY data_inicio DESC LIMIT 1
        """, (user_id,))
        sancao = cursor.fetchone()

        if sancao and sancao['data_fim'] and sancao['data_fim'] <= datetime.now():
            cursor.execute("UPDATE utilizadores SET estado = 'ativo' WHERE id = %s", (user_id,))
            ligacao.commit()
        else:
            data_fim_txt = sancao['data_fim'].strftime('%d/%m/%Y %H:%M') if sancao and sancao['data_fim'] else 'data indefinida'
            cursor.close()
            ligacao.close()
            session.clear()
            flash(f"Conta suspensa até {data_fim_txt}. Motivo: {sancao['motivo'] if sancao else 'Não especificado'}", 'erro')
            return redirect(url_for('auth.iniciar_sessao'))

    cursor.close()
    ligacao.close()

# ---------------------------------------------------------------------
# Rota Principal (Feed, Filtros de Conteúdo e Pesquisa com Tabs)
# ---------------------------------------------------------------------
@app.route('/')
def pagina_feed():
    ligacao = obter_ligacao_bd()
    if not ligacao:
        return render_template('index.html', publicacoes=[], contas=[])

    cursor = ligacao.cursor(dictionary=True)
    area = request.args.get('area')
    pesquisa = request.args.get('q')
    tipo_pesquisa = request.args.get('tipo', 'publicacoes')
    user_id = session.get('user_id') or 0

    query = """
        SELECT p.*, u.username AS autor_username, u.papel AS autor_papel,
               (SELECT COUNT(*) FROM gostos g WHERE g.publicacao_id = p.id) AS total_gostos,
               (SELECT COUNT(*) FROM gostos g WHERE g.publicacao_id = p.id AND g.user_id = %s) AS utilizador_gostou,
               (SELECT COUNT(*) FROM favoritos f WHERE f.publicacao_id = p.id AND f.user_id = %s) AS utilizador_favoritou
        FROM publicacoes p
        JOIN utilizadores u ON p.autor_id = u.id
        WHERE p.comunidade_id IS NULL
    """
    params = [user_id, user_id]

    # Organização por Áreas (Req. 32)
    if area == 'musica':
        query += " AND p.tipo_conteudo = 'musica'"
    elif area == 'livros':
        query += " AND p.tipo_conteudo = 'documento'"
    elif area == 'arte':
        query += " AND p.tipo_conteudo IN ('imagem', 'video')"

    # Pesquisa geral (Req. 14)
    contas = []
    if pesquisa:
        query += " AND (p.titulo LIKE %s OR p.texto_corpo LIKE %s OR u.username LIKE %s)"
        term = f"%{pesquisa}%"
        params.extend([term, term, term])

        # Pesquisa de contas de utilizadores
        cursor.execute("""
            SELECT u.id, u.username, u.papel, u.data_registo,
                   (SELECT COUNT(*) FROM publicacoes WHERE autor_id = u.id) AS total_publicacoes
            FROM utilizadores u
            WHERE u.username LIKE %s AND u.estado = 'ativo'
            ORDER BY u.username ASC
            LIMIT 30
        """, (term,))
        contas = cursor.fetchall()

    query += " ORDER BY p.data_publicacao DESC LIMIT 30"
    cursor.execute(query, tuple(params))
    publicacoes = cursor.fetchall()

    cursor.close()
    ligacao.close()

    return render_template('index.html',
                           publicacoes=publicacoes,
                           contas=contas,
                           area=area,
                           pesquisa=pesquisa,
                           tipo_pesquisa=tipo_pesquisa)

# ---------------------------------------------------------------------
# Rota do Perfil Pessoal (Req. 9, 10, 19)
# ---------------------------------------------------------------------
@app.route('/perfil')
def pagina_perfil():
    if not session.get('user_id'):
        return redirect(url_for('auth.iniciar_sessao'))

    tab = request.args.get('tab', 'publicacoes')
    user_id = session['user_id']

    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT * FROM utilizadores WHERE id = %s", (user_id,))
    utilizador = cursor.fetchone()

    itens = []
    if tab == 'comentarios':
        cursor.execute("""
            SELECT c.*, p.titulo AS titulo_publicacao 
            FROM comentarios c
            JOIN publicacoes p ON p.id = c.publicacao_id
            WHERE c.autor_id = %s AND c.eliminado = FALSE
            ORDER BY c.data_comentario DESC
        """, (user_id,))
        itens = cursor.fetchall()
    elif tab == 'favoritos':
        cursor.execute("""
            SELECT p.*, u.username AS autor_username,
                   (SELECT COUNT(*) FROM gostos g WHERE g.publicacao_id = p.id) AS total_gostos,
                   1 AS utilizador_gostou,
                   1 AS utilizador_favoritou
            FROM favoritos f
            JOIN publicacoes p ON p.id = f.publicacao_id
            JOIN utilizadores u ON p.autor_id = u.id
            WHERE f.user_id = %s
            ORDER BY f.data_adicao DESC
        """, (user_id,))
        itens = cursor.fetchall()
    elif tab == 'downloads':
        cursor.execute("""
            SELECT p.*, d.data_download 
            FROM downloads d
            JOIN publicacoes p ON p.id = d.publicacao_id
            WHERE d.user_id = %s
            ORDER BY d.data_download DESC
        """, (user_id,))
        itens = cursor.fetchall()
    else:  # publicacoes
        cursor.execute("""
            SELECT p.*,
                   (SELECT COUNT(*) FROM gostos g WHERE g.publicacao_id = p.id) AS total_gostos
            FROM publicacoes p
            WHERE p.autor_id = %s
            ORDER BY p.data_publicacao DESC
        """, (user_id,))
        itens = cursor.fetchall()

    cursor.close()
    ligacao.close()

    return render_template('perfil.html', utilizador=utilizador, tab=tab, itens=itens)

# ---------------------------------------------------------------------
# Rota da Página Pública de Utilizador (Req. 1, 14)
# ---------------------------------------------------------------------
@app.route('/utilizador/<int:user_id>')
def perfil_publico(user_id):
    ligacao = obter_ligacao_bd()
    cursor = ligacao.cursor(dictionary=True)

    cursor.execute("SELECT id, username, data_registo, papel FROM utilizadores WHERE id = %s", (user_id,))
    perfil = cursor.fetchone()

    if not perfil:
        cursor.close()
        ligacao.close()
        flash('Utilizador não encontrado.', 'erro')
        return redirect(url_for('pagina_feed'))

    cursor.execute("SELECT * FROM publicacoes WHERE autor_id = %s AND comunidade_id IS NULL ORDER BY data_publicacao DESC", (user_id,))
    publicacoes = cursor.fetchall()

    cursor.close()
    ligacao.close()
    return render_template('perfil_publico.html', perfil=perfil, publicacoes=publicacoes)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
