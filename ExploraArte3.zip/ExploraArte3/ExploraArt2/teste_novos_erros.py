import mysql.connector
from app import app

client = app.test_client()

def ligacao_teste():
    conn = mysql.connector.connect(
        host='localhost', user='root', password='A12345-a', database='explora_art'
    )
    conn.autocommit = True
    return conn

print("INICIANDO VALIDACAO DOS 4 NOVOS REQUISITOS...")

# ==============================================================================
# TESTE 1: Encadeamento de comentarios e notificacao de resposta
# ==============================================================================
client.get('/logout')
res_login = client.post('/login', data={'identificador': 'artista', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)
assert res_login.status_code == 200

res_com_raiz = client.post('/publicacao/5/comentar', data={'texto': 'Comentario original para teste de encadeamento.'}, follow_redirects=True)
assert res_com_raiz.status_code == 200

# Obter o ID do comentario recem-criado
conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
cur.execute("SELECT id FROM comentarios WHERE texto = 'Comentario original para teste de encadeamento.' ORDER BY id DESC LIMIT 1")
com_pai = cur.fetchone()
assert com_pai is not None, "Comentario pai nao encontrado na BD"
com_pai_id = com_pai['id']
conn.close()

# 2. Login como subscrito (ID=2) e responder ao comentario do artista
client.get('/logout')
client.post('/login', data={'identificador': 'subscrito', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)

res_resp = client.post('/publicacao/5/comentar', data={
    'texto': '@artista Concordo inteiramente com o seu comentario!',
    'comentario_pai_id': str(com_pai_id)
}, follow_redirects=True)
assert res_resp.status_code == 200

# Verificar se na base de dados o comentario tem o comentario_pai_id correto
conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
cur.execute("SELECT * FROM comentarios WHERE comentario_pai_id = %s", (com_pai_id,))
com_filho = cur.fetchone()
assert com_filho is not None, "Comentario filho nao foi associado ao pai_id"
assert com_filho['comentario_pai_id'] == com_pai_id

# Verificar se foi gerada notificacao de tipo 'resposta' para o artista (user_id=3)
cur.execute("""
    SELECT * FROM notificacoes 
    WHERE user_id = 3 AND tipo = 'resposta' 
    ORDER BY id DESC LIMIT 1
""")
notif_resp = cur.fetchone()
assert notif_resp is not None, "Notificacao de resposta nao gerada para o autor do comentario pai"
assert 'respondeu ao seu' in notif_resp['mensagem']
conn.close()

# Verificar se no HTML o comentario aparece com a indicacao do pai
res_html = client.get('/publicacao/5')
assert res_html.status_code == 200
html_pub = res_html.data.decode('utf-8')
assert 'Em resposta a @' in html_pub
assert 'responderComentario' in html_pub
assert 'indicador-resposta' in html_pub
print("[OK] REQUISITO 1: Encadeamento de comentarios (comentar um comentario) e notificacao de resposta validados!")

# ==============================================================================
# TESTE 2: Administrador da comunidade recebe notificacao de pedido de adesao
# ==============================================================================
conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
cur.execute("SELECT id FROM comunidades WHERE nome = 'Comunidade Privada Teste'")
com_existente = cur.fetchone()
if not com_existente:
    cur.execute("INSERT INTO comunidades (criador_id, nome, descricao, tipo) VALUES (1, 'Comunidade Privada Teste', 'Descricao privada', 'privada')")
    com_privada_id = cur.lastrowid
    cur.execute("INSERT INTO comunidade_membros (comunidade_id, user_id, papel, estado, data_adesao) VALUES (%s, 1, 'administrador', 'ativo', NOW())", (com_privada_id,))
else:
    com_privada_id = com_existente['id']

# Limpar possivel adesao previa do subscrito
cur.execute("DELETE FROM comunidade_membros WHERE comunidade_id = %s AND user_id = 2", (com_privada_id,))
cur.execute("DELETE FROM notificacoes WHERE user_id = 1 AND mensagem LIKE '%pediu para aderir%'")
cur.execute("DELETE FROM notificacoes WHERE user_id = 2 AND mensagem LIKE '%aprovado%'")
conn.close()

# Subscrito (user_id=2) pede para aderir a comunidade privada
res_aderir = client.post(f'/comunidade/{com_privada_id}/aderir', follow_redirects=True)
assert res_aderir.status_code == 200

# Verificar se admin (user_id=1) recebeu a notificacao do pedido de adesao
conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
cur.execute("""
    SELECT * FROM notificacoes 
    WHERE user_id = 1 AND tipo = 'sistema' AND mensagem LIKE '%pediu para aderir%' 
    ORDER BY id DESC LIMIT 1
""")
notif_admin = cur.fetchone()
assert notif_admin is not None, "Admin da comunidade NAO recebeu notificacao de pedido de adesao!"
assert 'pediu para aderir' in notif_admin['mensagem']
conn.close()

# Admin aprova o membro
client.get('/logout')
client.post('/login', data={'identificador': 'admin', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)
res_aprovar = client.post(f'/comunidade/{com_privada_id}/aprovar/2', follow_redirects=True)
assert res_aprovar.status_code == 200

# Subscrito deve ter recebido notificacao de aprovacao
conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
cur.execute("""
    SELECT * FROM notificacoes 
    WHERE user_id = 2 AND tipo = 'sistema' AND mensagem LIKE '%aprovado%' 
    ORDER BY id DESC LIMIT 1
""")
notif_aprov = cur.fetchone()
assert notif_aprov is not None, "Membro aprovado nao recebeu notificacao de aprovacao"
conn.close()
print("[OK] REQUISITO 2: Notificacao de pedido de adesao para administrador da comunidade validada!")

# ==============================================================================
# TESTE 3: Mensagens diretas (iniciar conversa pelo perfil e pela caixa de mensagens)
# ==============================================================================
# 1. Verificar botao no perfil publico de outro utilizador
client.get('/logout')
client.post('/login', data={'identificador': 'subscrito', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)

res_perf_artista = client.get('/utilizador/3')
assert res_perf_artista.status_code == 200
html_perf = res_perf_artista.data.decode('utf-8')
assert 'Enviar Mensagem' in html_perf
assert '/mensagens/3' in html_perf

# 2. Verificar seletor de Nova Conversa na pagina /mensagens
res_msg_box = client.get('/mensagens')
assert res_msg_box.status_code == 200
html_msg_box = res_msg_box.data.decode('utf-8')
assert 'Nova Conversa' in html_msg_box
assert 'artista' in html_msg_box

# 3. Enviar mensagem direta para o artista (ID=3)
res_envio = client.post('/mensagens/3', data={'texto': 'Ola Artista, parabens pelo trabalho!'}, follow_redirects=True)
assert res_envio.status_code == 200

conn = ligacao_teste()
cur = conn.cursor(dictionary=True)
cur.execute("SELECT * FROM mensagens_diretas WHERE remetente_id = 2 AND destinatario_id = 3 ORDER BY id DESC LIMIT 1")
msg_db = cur.fetchone()
assert msg_db is not None, "Mensagem direta nao foi guardada na base de dados"
assert msg_db['texto'] == 'Ola Artista, parabens pelo trabalho!'

# Destinatario deve ter recebido notificacao
cur.execute("SELECT * FROM notificacoes WHERE user_id = 3 AND mensagem LIKE '%nova mensagem de subscrito%' ORDER BY id DESC LIMIT 1")
notif_msg = cur.fetchone()
assert notif_msg is not None, "Destinatario da mensagem nao recebeu notificacao de sistema"
conn.close()

# 4. Login como artista e verificar conversa recebida
client.get('/logout')
client.post('/login', data={'identificador': 'artista', 'palavra_passe': 'Teste1234!'}, follow_redirects=True)

res_chat = client.get('/mensagens/2')
assert res_chat.status_code == 200
html_chat = res_chat.data.decode('utf-8')
assert 'Ola Artista, parabens pelo trabalho!' in html_chat
assert 'subscrito' in html_chat
print("[OK] REQUISITO 3: Mensagens diretas (iniciar pelo perfil e pela caixa com selecao) validadas!")

# ==============================================================================
# TESTE 4: Pesquisa com separadores (Tabs) entre Publicacoes e Contas de Utilizadores
# ==============================================================================
# 1. Pesquisa geral pelo termo 'artista' no separador de contas
res_pesq_contas = client.get('/?q=artista&tipo=contas')
assert res_pesq_contas.status_code == 200
html_pesq_contas = res_pesq_contas.data.decode('utf-8')
assert 'Contas de Utilizadores' in html_pesq_contas
assert 'Publicações' in html_pesq_contas
assert 'artista' in html_pesq_contas
assert 'Ver Perfil' in html_pesq_contas

# 2. Pesquisa geral pelo termo 'artista' no separador de publicacoes
res_pesq_pubs = client.get('/?q=artista&tipo=publicacoes')
assert res_pesq_pubs.status_code == 200
html_pesq_pubs = res_pesq_pubs.data.decode('utf-8')
assert 'Contas de Utilizadores' in html_pesq_pubs
assert 'Publicações' in html_pesq_pubs
print("[OK] REQUISITO 4: Pesquisa com sugestoes/separadores de contas e publicacoes validada!")

print("\nTODOS OS 4 NOVOS REQUISITOS FORAM TESTADOS E VALIDADOS COM 100% DE SUCESSO!")
