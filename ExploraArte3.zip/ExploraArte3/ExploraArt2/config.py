import os

class Configuracao:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'chave_secreta_explora_art_2026_segura'
    MYSQL_HOST = os.environ.get('MYSQL_HOST') or 'localhost'
    MYSQL_USER = os.environ.get('MYSQL_USER') or 'root'
    MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD') or 'A12345-a'
    MYSQL_DB = os.environ.get('MYSQL_DB') or 'explora_art'
    
    # Pasta de carregamento local de ficheiros
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads')
    
    # Limite global de tamanho no Flask (200MB máximo para MP4)
    MAX_CONTENT_LENGTH = 200 * 1024 * 1024