import mysql.connector
from mysql.connector import Error
from config import Configuracao

def obter_ligacao_bd():
    """Cria e devolve uma nova conexão com a base de dados MySQL."""
    try:
        ligacao = mysql.connector.connect(
            host=Configuracao.MYSQL_HOST,
            user=Configuracao.MYSQL_USER,
            password=Configuracao.MYSQL_PASSWORD,
            database=Configuracao.MYSQL_DB,
            charset='utf8mb4',
            collation='utf8mb4_unicode_ci'
        )
        return ligacao
    except Error as erro:
        print(f"Erro ao ligar à base de dados MySQL: {erro}")
        return None