from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from mysql.connector import Error
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
# Chave secreta necessária para gerir sessões e mensagens flash
app.secret_key = 'chave_secreta_explora_art_segura_2026'

# ----------------- CONEXÃO À BASE DE DADOS -----------------
def conectar_db():
    try:
        conexao = mysql.connector.connect(
            host='localhost',
            user='root',
            password='A12345-a',         # Coloca aqui a tua palavra-chave do MySQL se tiveres
            database='explora_art'
        )
        if conexao.is_connected():
            return conexao
    except Error as e:
        print(f"Erro ao conectar ao MySQL: {e}")
        return None

# ----------------- PÁGINA INICIAL (FEED DINÂMICO) -----------------
@app.route('/')
def index():
    publicacoes = []
    conexao = conectar_db()
    if conexao:
        cursor = conexao.cursor(dictionary=True)
        try:
            # Consulta para trazer publicações com o nome e papel do autor
            query = """
                SELECT p.*, u.username, u.papel 
                FROM publicacoes p
                JOIN utilizadores u ON p.autor_id = u.id
                ORDER BY p.data_publicacao DESC
            """
            cursor.execute(query)
            publicacoes = cursor.fetchall()
        except Error as e:
            print(f"Erro ao carregar publicações: {e}")
        finally:
            cursor.close()
            conexao.close()
            
    return render_template('index.html', publicacoes=publicacoes)

# ----------------- REGISTO DE UTILIZADOR -----------------
@app.route('/registar', methods=['GET', 'POST'])
def registar():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        # Validações de campos obrigatórios
        if not username or not email or not password:
            flash('Por favor, preenche todos os campos obrigatórios.', 'erro')
            return redirect(url_for('registar'))

        if password != confirm_password:
            flash('As palavras-chave não coincidem!', 'erro')
            return redirect(url_for('registar'))

        conexao = conectar_db()
        if conexao:
            cursor = conexao.cursor(dictionary=True)
            try:
                # Verificar se o username ou email já existem
                cursor.execute("SELECT id FROM utilizadores WHERE username = %s OR email = %s", (username, email))
                if cursor.fetchone():
                    flash('O nome de utilizador ou email já se encontra registado.', 'erro')
                    return redirect(url_for('registar'))

                # Encriptação da palavra-chave (RGPD e Segurança)
                password_encriptada = generate_password_hash(password)

                # Inserir novo utilizador
                query_user = """
                    INSERT INTO utilizadores (username, email, password_hash, papel, estado) 
                    VALUES (%s, %s, %s, 'registado', 'ativo')
                """
                cursor.execute(query_user, (username, email, password_encriptada))
                novo_user_id = cursor.lastrowid

                # Inicializar definições de acessibilidade/notificações padrão
                query_def = "INSERT INTO definicoes_conta (user_id) VALUES (%s)"
                cursor.execute(query_def, (novo_user_id,))

                conexao.commit()
                flash('Conta criada com sucesso! Podes agora iniciar sessão.', 'sucesso')
                return redirect(url_for('login'))

            except Error as e:
                conexao.rollback()
                flash(f'Erro ao criar conta: {e}', 'erro')
            finally:
                cursor.close()
                conexao.close()
        else:
            flash('Erro de ligação à base de dados.', 'erro')

    return render_template('registar.html')

# ----------------- LOGIN DE UTILIZADOR -----------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login_input = request.form.get('login_input', '').strip()
        password = request.form.get('password')

        conexao = conectar_db()
        if conexao:
            cursor = conexao.cursor(dictionary=True)
            try:
                query = "SELECT * FROM utilizadores WHERE username = %s OR email = %s"
                cursor.execute(query, (login_input, login_input))
                user = cursor.fetchone()

                if user:
                    # Verificação de estado de suspensão ou banimento (Requisito 3)
                    if user['estado'] == 'banido':
                        flash('Esta conta foi banida permanentemente por infração às regras.', 'erro')
                        return redirect(url_for('login'))
                    elif user['estado'] == 'suspenso':
                        flash('Esta conta encontra-se temporariamente suspensa.', 'erro')
                        return redirect(url_for('login'))

                    # Validação de credenciais encriptadas
                    if check_password_hash(user['password_hash'], password):
                        session['user_id'] = user['id']
                        session['username'] = user['username']
                        session['papel'] = user['papel']
                        session['is_subscribed'] = (user['papel'] in ['subscrito', 'administrador'])

                        flash(f'Sessão iniciada com sucesso. Olá, {user["username"]}!', 'sucesso')
                        return redirect(url_for('index'))
                    else:
                        flash('Palavra-chave incorreta.', 'erro')
                else:
                    flash('Utilizador ou email não registado.', 'erro')

            except Error as e:
                flash(f'Erro ao processar login: {e}', 'erro')
            finally:
                cursor.close()
                conexao.close()
        else:
            flash('Erro de ligação à base de dados.', 'erro')

    return render_template('login.html')

# ----------------- CRIAR PUBLICAÇÃO -----------------
@app.route('/criar-publicacao', methods=['POST'])
def criar_publicacao():
    if 'user_id' not in session:
        flash('Precisas de iniciar sessão para publicar conteúdos.', 'erro')
        return redirect(url_for('login'))

    titulo = request.form.get('titulo', '').strip()
    texto_corpo = request.form.get('texto_corpo', '').strip()
    tipo_conteudo = request.form.get('tipo_conteudo')
    tags = request.form.get('tags', '').strip()

    if not titulo or not tipo_conteudo or not tags:
        flash('Título, tipo de conteúdo e pelo menos uma tag são obrigatórios.', 'erro')
        return redirect(url_for('index'))

    conexao = conectar_db()
    if conexao:
        cursor = conexao.cursor()
        try:
            # 1. Inserir a publicação
            query_post = """
                INSERT INTO publicacoes (autor_id, tipo_conteudo, titulo, texto_corpo)
                VALUES (%s, %s, %s, %s)
            """
            cursor.execute(query_post, (session['user_id'], tipo_conteudo, titulo, texto_corpo))
            post_id = cursor.lastrowid

            # 2. Processar e associar tags
            lista_tags = [t.strip().replace('#', '') for t in tags.split(',') if t.strip()]
            for nome_tag in lista_tags:
                cursor.execute("INSERT IGNORE INTO tags (nome) VALUES (%s)", (nome_tag,))
                cursor.execute("SELECT id FROM tags WHERE nome = %s", (nome_tag,))
                tag_row = cursor.fetchone()
                if tag_row:
                    tag_id = tag_row[0]
                    cursor.execute("INSERT IGNORE INTO publicacao_tags (publicacao_id, tag_id) VALUES (%s, %s)", (post_id, tag_id))

            conexao.commit()
            flash('Publicação partilhada com sucesso!', 'sucesso')
        except Error as e:
            conexao.rollback()
            flash(f'Erro ao guardar publicação: {e}', 'erro')
        finally:
            cursor.close()
            conexao.close()

    return redirect(url_for('index'))

# ----------------- TERMINAR SESSÃO -----------------
@app.route('/logout')
def logout():
    session.clear()
    flash('Sessão terminada.', 'info')
    return redirect(url_for('index'))

# ----------------- ÁREAS CULTURAIS -----------------
@app.route('/musica')
def musica():
    return "<h1>Área de Música (Em desenvolvimento)</h1>"

@app.route('/livros')
def livros():
    return "<h1>Área de Livros (Em desenvolvimento)</h1>"

@app.route('/arte')
def arte():
    return "<h1>Área de Arte (Em desenvolvimento)</h1>"

if __name__ == '__main__':
    app.run(debug=True, port=5000)
